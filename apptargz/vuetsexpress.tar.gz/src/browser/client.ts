import { application } from "express";
import {
  createApp,
  defineComponent,
  h,
  onMounted,
} from "vue/dist/vue.esm-browser.prod";
import { hotReload, post } from "./api";

import OauthWidget from "./oauthwidget";
import { ConfigNode } from "./configeditor";

const conf = new ConfigNode("config");

const index = defineComponent({
  setup(props, context) {
    onMounted(() => {
      post("checkadmin").then((result) => {
        console.log(result);
      });
      post("getglobalconfig").then((result: any) => {
        console.log(result);
        conf.setFromBlob(result.content);
      });
    });
    return () => {
      return h("div", {}, [
        h("div", {}, [
          h(OauthWidget),
          h(
            "a",
            { href: "/man", rel: "noopener noreferrer", target: "_blank" },
            "Manager"
          ),
        ]),
        h("hr"),
        h(
          conf.defineComponent(),
          {
            onUpload: (ev) => {
              post("setconfig", { config: conf.serialize(conf) }).then(
                (result) => {
                  console.log(result);
                  window.alert(JSON.stringify(result));
                }
              );
            },
          },
          []
        ),
      ]);
    };
  },
  template: "index",
});

const app = createApp(index);

app.mount("#app");

hotReload();
