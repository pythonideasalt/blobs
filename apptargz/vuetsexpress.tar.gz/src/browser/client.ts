import {
  createApp,
  defineComponent,
  h,
  onMounted,
  reactive,
  ref,
} from "vue/dist/vue.esm-browser.prod";
import { hotReload, post, setLogger } from "./api";
import {
  link,
  centeredFlex,
  confirm,
  globalReact,
  alertJson,
  confirmButton,
} from "./misc";

import OauthWidget from "./oauthwidget";
import { ConfigNode } from "./configeditor";
import { Tabs } from "./tabs";
import { EventConsumer } from "./sse";
import { WebLogger } from "./logger";
import { CHAT_MESSAGE_MAX_LENGTH } from "../shared/config";
import { Board } from "./board";
import { randomQuote } from "../shared/quotes";
import { CreateSeek, ShowSeek } from "./createseek";
import { Seek } from "../shared/models";
import { headSort } from "../shared/utils";

//////////////////////////////////////////////////////////////////////

const logger = new WebLogger();
setLogger(logger.logger);

const react = reactive({
  activeUsers: [],
  messages: [],
  header: "",
  seeks: [],
});

//////////////////////////////////////////////////////////////////////

function setQuote() {
  const [quote, by] = randomQuote(150, 40);
  react.header = `" ${quote} " <span style="font-weight:bold; color:#0f0;">${by}</span>`;
}

setInterval(() => {
  setQuote();
}, 30000);

setQuote();

//////////////////////////////////////////////////////////////////////

function setSeeks(ev: any) {
  react.seeks = ev.seeks.map((s: any) => new Seek(s));
}

function delSeek(s: Seek, ev: any) {
  post("msg", s.setDelete(ev.ctrlKey).serialize()).then((result: any) => {
    //alertJson(result);
  });
}

//////////////////////////////////////////////////////////////////////

new EventConsumer({
  logger: logger.logger,
  logFilter: (ev: any) => {
    if (["tick", "setpingdelay", "seeks", "activeusers"].includes(ev.kind))
      return false;
    return true;
  },
  eventCallback: (ev: any) => {
    if (ev.kind === "activeusers") {
      react.activeUsers = ev.activeUsers;

      return;
    }

    if (ev.kind === "chat") {
      react.messages = ev.messages;

      return;
    }

    if (ev.kind === "seeks") {
      setSeeks(ev);

      return;
    }
  },
}).mount();

//////////////////////////////////////////////////////////////////////

const tabs = new Tabs("contentmiddle", [
  { caption: "Analysis", id: "analysisboard", icon: "search" },
  {
    caption: "Profile",
    id: "profile",
    icon: "profile",
    iconbutton: "iconbutton2",
  },
  { caption: "Seek", id: "createseek" },
  { caption: "Config", id: "config", adminOnly: true },
  { caption: "Logs", id: "logs", adminOnly: true },
]);

//////////////////////////////////////////////////////////////////////

const analysisBoard = new Board();
const analysisBoardComp = h(analysisBoard.defineComponent());

const analysisboard = h(
  "div",
  {
    style: {
      padding: "5px",
    },
    onClick: (ev: any) => {
      if (ev.ctrlKey && confirm("delete analysis", "delanalysis")) {
        post("delanalysis").then((result: any) => {
          //alertJson(result);
        });
      }
    },
  },
  analysisBoardComp
);

const profile = h(
  "div",
  {
    onClick: (ev: any) => {
      if (ev.ctrlKey && confirm("delete users", "delusers")) {
        post("delusers").then((result: any) => {
          //alertJson(result);
        });
      }
    },
    class: "profile",
  },
  [
    h(
      "button",
      {
        class: "login",
        onClick: () => {
          const token = window.prompt("Token");
          if (token) {
            localStorage.setItem("USER_TOKEN", `${token}`);
            document.location.reload();
          }
        },
      },
      "Login With Token"
    ),
    h(
      "button",
      {
        class: "reveal",
        onClick: () => {
          alertJson({ USER_TOKEN: localStorage.getItem("USER_TOKEN") });
        },
      },
      "Reveal Token"
    ),
  ]
);

const createSeek = new CreateSeek();
const createseek = h(createSeek.defineComponent());

const conf = new ConfigNode("config");
const config = h(conf.defineComponent(), {
  onUpload: (ev: any) => {
    post("setconfig", { config: conf.serialize(conf) }).then((result) => {
      alertJson(result);
    });
  },
});

const logs = h("div", { class: "logscont" }, [
  h("div", { class: "controls" }, [
    confirmButton("Delete Db", "delete entire databse", "deldb", function () {
      post("deldb").then((result: any) => {
        //alertJson(result);
      });
    }),
  ]),
  h("div", { class: "weblogger" }, h(logger.defineComponent())),
]);

const contentMiddleDispatch = {
  analysisboard,
  profile,
  createseek,
  config,
  logs,
};

//////////////////////////////////////////////////////////////////////

const topHeader = () =>
  centeredFlex(h("div", { style: { color: "#ff0" }, innerHTML: react.header }));

const headerLeft = () => centeredFlex("header left");

const headerMiddle = () => h(tabs.defineComponent());

const headerRightRef = ref(0);
const headerRight = () =>
  h(OauthWidget, { logger: logger.logger, watch: headerRightRef });

const contentLeftTop = () =>
  h(
    "div",
    {},
    react.activeUsers.map((user: any) =>
      h("div", { class: "activeuser" }, user.username)
    )
  );

const chatInput = () =>
  h("input", {
    class: "chatinput",
    type: "text",
    maxlength: CHAT_MESSAGE_MAX_LENGTH,
    onKeyup: (ev: any) => {
      if (ev.keyCode === 13) {
        const message = ev.target.value;
        ev.target.value = "";
        post("chat", { message }).then((result: any) => {
          //alertJson(result)
        });
      }
    },
  });

const chatMessagesProps = () => ({
  class: "chatmessages",
  onClick: (ev: any) => {
    if (ev.ctrlKey && confirm("delete chat", "delchat")) {
      post("delchat", {}).then((result: any) => {
        //alertJson(result)
      });
    }
  },
});

const chatMessagesNode = () =>
  react.messages
    .slice()
    .reverse()
    .map((message: any) =>
      h("div", {}, [
        h("div", { class: "username" }, message.user.username),
        h(
          "div",
          {
            class: "message",
            onClick: (ev: any) => {
              ev.stopPropagation();
              if (
                ev.ctrlKey &&
                confirm(`delete message < ${message.message} >`, "del")
              ) {
                ev.stopPropagation();

                post("deletemessage", { id: message.id }).then(
                  (result: any) => {
                    //alertJson(result)
                  }
                );
              }
            },
          },
          message.message
        ),
      ])
    );

const contentLeftBottom = () => [
  h("div", chatMessagesProps(), chatMessagesNode()),
  chatInput(),
];

const contentMiddle = () =>
  ["logs", "createseek", "config", "profile"].includes(tabs.effSelectedTabId())
    ? (contentMiddleDispatch as any)[tabs.effSelectedTabId()]
    : centeredFlex((contentMiddleDispatch as any)[tabs.effSelectedTabId()]);

const contentRightTopSeeks = () =>
  (
    headSort(
      react.seeks,
      (s: any) => s.user.id === globalReact.user.id
    ) as Seek[]
  ).map((s: any) => [
    (s as any).tailBegin ? h("hr") : undefined,
    h(
      new ShowSeek(s)
        .setOnClick((s: Seek, ev: any) => {
          ev.stopPropagation();
          delSeek(s, ev);
        })
        .defineComponent(),
      {
        style: (s as any).isHead
          ? {
              "box-shadow": "2px 2px #0f0",
            }
          : {},
      }
    ),
  ]);

const contentRightTop = () =>
  h(
    "div",
    {
      onClick: (ev: any) => {
        if (ev.ctrlKey && confirm("delete seeks", "delseeks")) {
          post("delseeks").then((result: any) => {
            //alertJson(result);
          });
        }
      },
    },
    contentRightTopSeeks()
  );

const contentRightBottom = () => centeredFlex("content right bottom");

const footerLeft = () => centeredFlex("footer left");

const footerMiddle = () => centeredFlex("footer middle");

const footerRight = () => centeredFlex("footer right");

const bottomFooter = () =>
  centeredFlex([
    link("https://github.com/pythonideasalt/vuetsexpress", "Source on GitHub"),
    globalReact.isAdmin ? link("/man", "Manager") : undefined,
  ]);

//////////////////////////////////////////////////////////////////////

function indexOnMounted() {
  post("getglobalconfig").then((result: any) => {
    conf.setFromBlob(result.content);
  });
  post("getactiveusers").then((result: any) => {
    const activeUsers = result.activeUsers;
    if (Array.isArray(activeUsers)) {
      react.activeUsers = result.activeUsers;
    }
  });
  post("getchat").then((result: any) => {
    react.messages = result.messages;
  });
  post("getseeks").then((result: any) => {
    setSeeks(result);
  });
}

//////////////////////////////////////////////////////////////////////

const index = defineComponent({
  setup() {
    onMounted(indexOnMounted);
    return () => {
      const indexNode = h("div", { class: "app" }, [
        h("div", { class: "grid" }, [
          h(
            "div",
            {
              class: "topheader",
              onClick: (ev: any) => {
                if (ev.ctrlKey) {
                  alertJson(APP_CONF);
                }
              },
            },
            topHeader()
          ),
          h("div", { class: ["header", "left"] }, headerLeft()),
          h("div", { class: ["header", "middle"] }, headerMiddle()),
          h(
            "div",
            {
              class: ["header", "right"],
              ref: headerRightRef,
              id: "headerrightref",
            },
            headerRight()
          ),
          h("div", { class: ["content", "left", "top"] }, contentLeftTop()),
          h(
            "div",
            { class: ["content", "left", "bottom"] },
            contentLeftBottom()
          ),
          h(
            "div",
            {
              class: ["content", "middle"],
              style: {
                overflow:
                  tabs.effSelectedTabId() === "logs"
                    ? "initial"
                    : "scroll !important",
              },
            },
            contentMiddle()
          ),
          h("div", { class: ["content", "right", "top"] }, contentRightTop()),
          h(
            "div",
            { class: ["content", "right", "bottom"] },
            contentRightBottom()
          ),
          h("div", { class: ["footer", "left"] }, footerLeft()),
          h("div", { class: ["footer", "middle"] }, footerMiddle()),
          h("div", { class: ["footer", "right"] }, footerRight()),
          h("div", { class: "bottomfooter" }, bottomFooter()),
        ]),
      ]);
      return indexNode;
    };
  },
  template: "index",
});

//////////////////////////////////////////////////////////////////////

const app = createApp(index);

app.mount("#app");

//////////////////////////////////////////////////////////////////////

setTimeout(() => {
  const welcomeElement = document.getElementById("welcome") as any;

  welcomeElement.style.display = "none";

  const appContElement = document.getElementById("appcont") as any;

  appContElement.style.display = "initial";

  hotReload();
}, 3000);
