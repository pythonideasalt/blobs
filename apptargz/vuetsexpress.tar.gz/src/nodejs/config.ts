import { envIntElse } from "./utils";
import { DAY } from "../shared/time";

export const LOGIN_INTERVAL = envIntElse("LOGIN_INTERVAL", 60000);
export const CHECK_LICHESS_PROFILE_AFTER = DAY;
