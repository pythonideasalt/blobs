import { Db, Collection } from "./mongodb";
import { Router, fetchJson } from "./utils";
import { SseServer } from "./sse";
import { randUserName } from "../shared/randusername";
import { uid, areStringArraysEqual } from "../shared/utils";
import { LOGIN_INTERVAL } from "./config";
import _ from "lodash";

const lichessHost = "https://lichess.org";
const MAX_USERNAME_LENGTH = 20;

export type LoginSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Login {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  userIdsColl: Collection;
  usersColl: Collection;

  lastSeens: { [key: string]: number } = {};

  lastActives: string[] = [];

  debounceSendActiveUsersToAll = _.debounce(
    this.sendActiveUsers.bind(this),
    3000
  );

  constructor(ls: LoginSetup) {
    this.appDb = ls.appDb;
    this.api = ls.api;
    this.sseServer = ls.sseServer;
    this.userIdsColl = this.appDb.collection("userids", {
      onConnect: this.userIdsConnected.bind(this),
    });
    this.usersColl = this.appDb.collection("users", {
      onConnect: this.usersConnected.bind(this),
    });

    this.mount();
  }

  async userIdsConnected() {
    return;
    const userIds = await this.userIdsColl.getAll();
    console.log({ userIds });
  }

  async usersConnected() {
    return;
    const users = await this.usersColl.getAll();
    console.log({ users });
  }

  getActiveUserIds() {
    const now = Date.now();
    return Object.keys(this.lastSeens).filter(
      (userId) => now - this.lastSeens[userId] < 2 * LOGIN_INTERVAL
    );
  }

  getUsersByIds(ids: string[]) {
    return ids.map((id) => this.usersColl.docs[id]);
  }

  sendActiveUsers() {
    const activeUsers = this.getUsersByIds(this.getActiveUserIds());
    const ev = {
      kind: "activeusers",
      activeUsers,
    };
    this.sseServer.sendEventToAllConsumers(ev);
  }

  checkActivesChanged() {
    const actives = this.getActiveUserIds();

    if (!areStringArraysEqual(actives, this.lastActives)) {
      console.log("active users changed");
      this.debounceSendActiveUsersToAll();
    }

    this.lastActives = actives;
  }

  setUser(res: any, blob: any) {
    blob.LOGIN_INTERVAL = LOGIN_INTERVAL;
    const userId = blob.userId;

    this.lastSeens[userId] = Date.now();

    this.checkActivesChanged();

    res.json(blob);
  }

  setRandUser(res: any) {
    const token = uid();
    const userId = uid();
    const username = randUserName(MAX_USERNAME_LENGTH);
    this.userIdsColl.setDocById(token, {
      userId,
    });
    this.usersColl.setDocById(userId, {
      username,
    });
    this.setUser(res, {
      userId,
      setUsername: username,
      setUserToken: token,
    });
  }

  async login(req: any, res: any) {
    const token = req.body.token;
    //console.log("login with token", token);
    const existingToken = await this.userIdsColl.getDocById(token, "lr");
    //console.log("existing token", existingToken)

    if (existingToken) {
      const userId = existingToken.userId;
      const existingUser = await this.usersColl.getDocById(userId, "lr");
      //console.log("existing user", existingUser)
      if (existingUser) {
        this.setUser(res, {
          userId,
          setUsername: existingUser.username,
        });

        return;
      } else {
        console.error("fatal, token exists without user");
        this.setRandUser(res);

        return;
      }
    }

    const accountResp = await fetchJson({
      url: `${lichessHost}/api/account`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    if (accountResp.ok) {
      const account = accountResp.json;
      if (account.error) {
        this.setRandUser(res);
      } else {
        this.userIdsColl.setDocById(token, {
          userId: account.id,
        });
        this.usersColl.setDocById(account.id, {
          username: account.username,
        });
        this.setUser(res, {
          userId: account.id,
          setUsername: account.username,
        });
      }
    } else {
      this.setRandUser(res);
    }
  }

  mount() {
    this.api.post("/login", (req: any, res: any) => {
      this.login(req, res);
    });

    setInterval(this.checkActivesChanged.bind(this), LOGIN_INTERVAL / 2);

    return this;
  }
}
