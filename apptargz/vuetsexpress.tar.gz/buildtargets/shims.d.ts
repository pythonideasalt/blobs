declare module "vue/dist/vue.esm-browser.prod";
declare const APP_CONF: { [key: string]: any };
