import {
  defineComponent,
  h,
  onMounted,
  reactive,
} from "vue/dist/vue.esm-browser.prod";

import { Chessground } from "@publishvue/chessground";
import { px } from "./misc";
import { uid } from "../shared/utils";
import { Game } from "../chessops";

const game = Game();
console.log("game", game.serialize());

export class Board {
  id = uid();
  board: any;
  size = 360;
  react = reactive({
    key: 0,
  });

  constructor() {}

  renderFunction() {
    const innerContainer = h("div", {
      id: this.id,
      style: { width: px(this.size), height: px(this.size) },
      class: ["maplebackground", "is2d"],
    });
    const outerContainer = h(
      "div",
      { style: { width: px(this.size), height: px(this.size) } },
      [innerContainer]
    );

    const board = h("div", { key: this.react.key, class: "board" }, [
      outerContainer,
    ]);

    return outerContainer;
  }

  onResize() {
    this.size = Math.floor((window.innerHeight - 200) / 8) * 8;

    this.react.key++;
  }

  onMounted() {
    this.board = Chessground(document.getElementById(this.id) as any);

    this.board.set({ fen: game.reportFen() });

    window.addEventListener("resize", () => {
      this.onResize();
    });

    this.onResize();
  }

  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        onMounted(() => {
          self.onMounted.bind(self)();
        });

        return self.renderFunction.bind(self);
      },
    });
  }
}
