export class ChatMessage {
  message: "message";
  createdAt = Date.now();
  userId = "?";
  username = "?";

  constructor(blob: any) {
    this.deserialize(blob);
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.message = blob.message || this.message;
      this.createdAt = blob.createdAt || this.userId;
      this.userId = blob.userId || this.userId;
      this.username = blob.username || this.username;
    }

    return this;
  }

  serialize() {
    return {
      message: this.message,
      createdAt: this.createdAt,
      userId: this.userId,
      username: this.username,
    };
  }
}
