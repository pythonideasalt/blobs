export const CHAT_MESSAGE_MAX_LENGTH = 200;
export const DEFAULT_VARIANT = "atomic";
