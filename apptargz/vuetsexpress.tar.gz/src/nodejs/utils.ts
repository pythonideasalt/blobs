import express from "express";
import path from "path";

export const ADMIN_PASS = process.env.ADMIN_PASS || "admin";

export class Router {
  router = express.Router();

  constructor() {
    this.router.use(express.json());

    this.router.use((req: any, res: any, next: any) => {
      req.isAdmin = false;
      if (req.body) {
        if (req.body.ADMIN_PASS === ADMIN_PASS) {
          req.isAdmin = true;
        }
      }
      next();
    });
  }

  sendView(res: any, name: string) {
    res.sendFile(path.join(__dirname, "..", "views", name));
  }

  sendDist(res: any, name: string) {
    res.sendFile(path.join(__dirname, "..", "dist", name));
  }

  sendModule(res: any, name: string) {
    res.sendFile(path.join(__dirname, "..", "node_modules", name));
  }

  postAdmin(endpoint: string, handler: any) {
    this.router.post("/" + endpoint, (req: any, res: any) => {
      if (req.isAdmin) {
        handler(req, res);
      } else {
        res.json({ endpoint, error: "Not Admin Authorized" });
      }
    });
  }

  get(endpoint: string, handler: any) {
    this.router.get(endpoint, handler);
  }

  mount(endpoint: string, parent: any) {
    parent.use(endpoint, this.router);
    return this;
  }
}

export function envIntElse(key: string, def: number): number {
  const stored = process.env[key];
  if (typeof stored === "undefined") {
    return def;
  }
  const parsed = parseInt(stored);
  if (isNaN(parsed)) {
    return def;
  }
  return parsed;
}
