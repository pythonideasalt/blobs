export const SSE_DEFAULT_DROP_DELAY = 120000;
export const SSE_DEFAULT_TICK_DELAY = 30000;

export function uid() {
  return (
    "uid_" + Date.now().toString(36) + Math.random().toString(36).substring(2)
  );
}

export const DEFAULT_LOGGER_CAPACITY = 100;

export type LoggerConfig = {
  capacity?: number;
  changeCallback?: any;
  skipConsole?: boolean;
};

const DEFAULT_LOGGER_CONFIG: LoggerConfig = {
  capacity: DEFAULT_LOGGER_CAPACITY,
  changeCallback: () => {},
  skipConsole: false,
};

export type LogDisposition =
  | "log"
  | "info"
  | "success"
  | "fail"
  | "warn"
  | "error";

export class LogItem {
  owner: string = "general";
  disposition: LogDisposition = "log";
  message: string = "log message";
  time: number = Date.now();

  constructor(owner: string, disposition: LogDisposition, message: string) {
    this.owner = owner;
    this.disposition = disposition;
    this.message = message;
  }

  asText() {
    return `< ${this.owner} > [ ${this.disposition} ] : ${this.message} @ ${this.time}`;
  }
}

export class Logger {
  config: LoggerConfig = DEFAULT_LOGGER_CONFIG;
  buffer: LogItem[] = [];

  constructor(lcOpt?: LoggerConfig) {
    if (lcOpt) {
      this.config = { ...DEFAULT_LOGGER_CONFIG, ...lcOpt };
    }
  }

  log(li: LogItem) {
    this.buffer.unshift(li);

    while (
      this.buffer.length > (this.config.capacity || DEFAULT_LOGGER_CAPACITY)
    )
      this.buffer.pop();

    if (!this.config.skipConsole) {
      if (li.disposition === "error") {
        console.error(li.asText());
      } else if (li.disposition === "info") {
        console.info(li.asText());
      } else if (li.disposition === "warn") {
        console.warn(li.asText());
      } else {
        console.log(li.asText());
      }
    }

    if (this.config.changeCallback) {
      this.config.changeCallback(li, this.buffer);
    }
  }
}
