import { MongoClient } from "mongodb";
import { Logger, LogItem, LogDisposition } from "../shared/utils";

const DEFAULT_MONGODB_URI =
  process.env.MONGODB_URI || "mongodb://localhost:27017";

export type MongoConfig = {
  MONGODB_URI?: string;
  logger?: Logger;
};

export const DEFAULT_MONGO_CONFIG: MongoConfig = {
  MONGODB_URI: DEFAULT_MONGODB_URI,
  logger: new Logger(),
};

export class Client {
  config: MongoConfig = DEFAULT_MONGO_CONFIG;

  client: any = undefined;

  dbs: Db[] = [];

  constructor(configOpt?: MongoConfig) {
    if (configOpt) this.config = { ...DEFAULT_MONGO_CONFIG, ...configOpt };

    const uri = this.config.MONGODB_URI || DEFAULT_MONGODB_URI;

    this.client = new MongoClient(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    } as any);
  }

  log(disposition: any, message: string) {
    this.config.logger?.log(new LogItem("mongodb", disposition, message));
  }

  listDbs() {
    return this.client.db().admin().listDatabases();
  }

  connect() {
    return new Promise((resolve) => {
      this.client.connect((err: any) => {
        if (err) {
          const report = {
            status: "MongoDb connection failed",
            error: err,
            success: false,
          };
          this.log("error", JSON.stringify(report, null, 2));
          resolve(report);
        } else {
          this.log("success", "MongoDb connected!");
          Promise.all(
            [this.listDbs()].concat(this.dbs.map((db) => db.onConnect()))
          ).then((result) => {
            resolve({
              error: false,
              success: true,
              onConnect: result.slice(1),
              dbs: JSON.stringify(
                result[0].databases.map((db: any) => db.name)
              ),
            });
          });
        }
      });
    });
  }

  db(name: string) {
    const db = new Db(name, this);
    this.dbs.push(db);
    return db;
  }
}

export type CollectionConfig = {};

export const DEFAULT_COLLECTION_CONFIG: CollectionConfig = {};

export class Collection {
  name: string;
  parentDb: Db;
  collection: any;
  config: CollectionConfig = DEFAULT_COLLECTION_CONFIG;
  docs: any[] = [];

  constructor(name: string, parentDb: Db, configOpt?: CollectionConfig) {
    this.name = name;
    this.parentDb = parentDb;
    this.collection = parentDb.db.collection(name);
    if (configOpt) this.config = { ...DEFAULT_COLLECTION_CONFIG, ...configOpt };
  }

  log(disposition: LogDisposition, message: string) {
    this.parentDb.parentClient.config.logger?.log(
      new LogItem("mongodbcoll", disposition, message)
    );
  }

  onConnect() {
    return new Promise((resolve) => {
      const report = { coll: this.name, connected: true };
      this.log("info", JSON.stringify(report, null, 2));
      resolve(report);
    });
  }
}

export type DbConfig = {};

export const DEFAULT_DB_CONFIG: DbConfig = {};

export class Db {
  name: string;
  parentClient: Client;

  config: DbConfig = DEFAULT_DB_CONFIG;

  db: any;

  collections: Collection[] = [];

  constructor(name: string, parentClient: Client, configOpt?: DbConfig) {
    this.name = name;
    this.parentClient = parentClient;
    if (configOpt) this.config = { ...DEFAULT_DB_CONFIG, configOpt };
    this.db = this.parentClient.client.db(name);
  }

  collection(name: string, config?: any) {
    const coll = new Collection(name, this, config);
    this.collections.push(coll);
    return coll;
  }

  log(disposition: LogDisposition, message: string) {
    this.parentClient.config.logger?.log(
      new LogItem("mongodbdb", disposition, message)
    );
  }

  onConnect() {
    return new Promise((resolve) => {
      this.log(
        "info",
        JSON.stringify({ db: this.name, connecting: true }, null, 2)
      );
      Promise.all(this.collections.map((coll) => coll.onConnect())).then(
        (result) => {
          resolve(result);
        }
      );
    });
  }
}
