import express from "express";
import { Router } from "./utils";
import { SseServer } from "./sse";
import { Client } from "./mongodb";
import { Static } from "./static";
import { Manager } from "./manager";
import { Login } from "./login";
import { Chat } from "./chat";
import { Chess } from "./chess";
import { PORT, APP_NAME, APP_DISPOSITION } from "./config";

////////////////////////////////////////////////////////////////////
// set up app

const app = express();

const router = new Router().mount("/", app);
const api = new Router().mount("/api", app);

new Static().mount(router);

const sseServer = new SseServer().mount(api);

const manager = new Manager().mount(api);

const client = new Client();

const appDb = client.db(APP_NAME);

const login = new Login({
  appDb,
  api,
  sseServer,
});

new Chat({
  appDb,
  api,
  sseServer,
});

new Chess({
  appDb,
  api,
  sseServer,
  login,
});

////////////////////////////////////////////////////////////////////
// init app

const initItems: any[] = [];

initItems.push(manager.init());
initItems.push(client.connect());

function init() {
  return new Promise((resolve) => {
    Promise.all(initItems)
      .then((initResult) => {
        resolve(initResult);
      })
      .catch((err) => {
        resolve({ error: err });
      });
  });
}

////////////////////////////////////////////////////////////////////
// start server

init().then((initResult) => {
  console.log({ initResult });

  app.listen(PORT, () => {
    console.log(
      `< ${APP_NAME} > < ${APP_DISPOSITION} > listening on port < ${PORT} >`
    );
  });
});
