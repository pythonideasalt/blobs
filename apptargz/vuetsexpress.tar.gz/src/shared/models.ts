import { uid } from "./utils";

export const CHESSOPS_VARIANT_KEYS = [
  "chess",
  "antichess",
  "atomic",
  "crazyhouse",
  "horde",
  "kingofthehill",
  "racingkings",
  "3check",
] as const;

export type CHESSOPS_VARIANT_KEY = typeof CHESSOPS_VARIANT_KEYS[number];

export class Variant {
  chessopsKey: CHESSOPS_VARIANT_KEY = "chess";
  displayName = "Standard";
  aliasRegex = "^chess|^standard";

  constructor(
    chessopsKey: CHESSOPS_VARIANT_KEY,
    displayName: string,
    aliasRegex: string
  ) {
    this.chessopsKey = chessopsKey;
    this.displayName = displayName;
    this.aliasRegex = aliasRegex;
  }
}

export const ALLOWED_VARIANTS = [
  new Variant("chess", "Standard", "^chess|standard"),
  new Variant("antichess", "Antichess", "^anti|giveaway|give away|loser"),
  new Variant("atomic", "Atomic", "atom"),
  //new Variant("crazyhouse", "Crazyhouse", "crazy"),
  new Variant("horde", "Horde", "horde"),
  new Variant(
    "kingofthehill",
    "King of the Hill",
    "king of the hill|kingofthehill"
  ),
  new Variant("racingkings", "Racing Kings", "racing kings|racingkings"),
  new Variant("3check", "Three Check", "3check|three check|threecheck"),
];

export class User {
  userId = "?";
  username = "?";
  lichessCheckedAt = 0;
  lichessProfile = undefined;

  constructor(blob: any) {
    this.deserialize(blob);
  }

  clone() {
    return new User(this.serialize());
  }

  cloneLight() {
    const user = this.clone();
    user.lichessProfile = undefined;
    return user;
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.userId = blob.userId || this.userId;
      this.username = blob.username || this.username;
      this.lichessCheckedAt = blob.lichessCheckedAt || 0;
      this.lichessProfile = blob.lichessProfile;
    }

    return this;
  }

  serialize() {
    return {
      userId: this.userId,
      username: this.username,
      lichessCheckedAt: this.lichessCheckedAt,
      lichessProfile: this.lichessProfile,
    };
  }
}

export class ChatMessage {
  id = uid();
  message = "message";
  createdAt = Date.now();
  user = new User({});

  constructor(blob: any) {
    this.deserialize(blob);
  }

  age() {
    return Date.now() - this.createdAt;
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.id = blob.id || this.id;
      this.message = blob.message || this.message;
      this.createdAt = blob.createdAt || this.createdAt;
      this.user = this.user.deserialize(blob.user);
    }

    return this;
  }

  serialize() {
    return {
      id: this.id,
      message: this.message,
      createdAt: this.createdAt,
      user: this.user.serialize(),
    };
  }
}
