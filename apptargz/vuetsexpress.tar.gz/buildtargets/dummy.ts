// necessary to satisfy ts compiler at least one input where tsconfig is requirement

// https://stackoverflow.com/questions/41211566/tsconfig-json-buildno-inputs-were-found-in-config-file
