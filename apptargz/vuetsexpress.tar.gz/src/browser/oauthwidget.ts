import { Oauth } from "./oauth";
import { post } from "./api";
import {
  defineComponent,
  h,
  onMounted,
  reactive,
} from "vue/dist/vue.esm-browser.prod";
import { Logger } from "../shared/utils";
import { globalReact } from "./misc";

function setAdminPass() {
  const pass = window.prompt("Admin Pass");

  if (pass) {
    localStorage.setItem("ADMIN_PASS", pass);
  }

  document.location.reload();
}

export default defineComponent({
  props: {
    username: {
      type: String,
      default: "?",
    },
    logger: {
      type: Object,
      default: () => new Logger({ owner: "oauthwidget" }),
    },
  },
  setup(props: any) {
    const oauth = new Oauth();
    const react = reactive({
      key: 0,
      admin: false,
    });

    function checkAdmin() {
      post("checkadmin").then((result: any) => {
        react.key++;
        if (result.error) {
          react.admin = false;
          globalReact.isAdmin = false;
        } else {
          react.admin = true;
          globalReact.isAdmin = true;
        }
        props.logger.log({ admin: !!react.admin }, "oauthwidgetcheckadmin");
      });
    }

    let loginInterval: any;

    function login() {
      post("login", { token: localStorage.getItem("USER_TOKEN") }).then(
        (result: any) => {
          if (result.setUsername) {
            props.username = result.setUsername;
            globalReact.username = result.setUsername;
          }
          const setUserToken = result.setUserToken;
          if (setUserToken) {
            props.logger.log({ setUserToken }, "oauthwidgetlogin");
            localStorage.setItem("USER_TOKEN", setUserToken);
          }
          const LOGIN_INTERVAL = result.LOGIN_INTERVAL;
          if (LOGIN_INTERVAL && !loginInterval) {
            props.logger.log({ LOGIN_INTERVAL }, "oauthwidgetlogin");
            loginInterval = setInterval(login, LOGIN_INTERVAL);
          }
        }
      );
    }

    onMounted(async () => {
      await oauth.init();

      /*const account: any = await oauth.account();

      if (typeof account === "object" && account.username) {
        props.username = account.username;
      }*/

      login();

      checkAdmin();
    });

    return () => {
      return h("div", { class: "oauthwidget", key: react.key }, [
        h("div", { class: "cont" }, [
          h(
            "button",
            {
              onClick: (ev: any) => {
                if (ev.ctrlKey) {
                  setAdminPass();
                } else {
                  oauth.login();
                }
              },
            },
            "Login"
          ),
          h(
            "button",
            {
              onClick: () => {
                oauth.logout();
              },
            },
            "Logout"
          ),
          h("div", { class: "username" }, props.username),
          react.admin ? h("div", { class: "admin" }, "A") : undefined,
        ]),
      ]);
    };
  },
});
