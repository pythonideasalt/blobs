import { TimeControl } from "./models";

export const CHAT_MESSAGE_MAX_LENGTH = 200;
export const DEFAULT_VARIANT = "atomic";
export const DEFAULT_RATED = true;
export const ALLOWED_ROUNDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
export const DEFAULT_ROUNDS = 2;
