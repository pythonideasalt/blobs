import { defineComponent, h, onMounted } from "vue/dist/vue.esm-browser.prod";

export function link(href: string, captionOpt?: string, targetOpt?: string) {
  const caption = captionOpt || href;
  const target = targetOpt || "_blank";
  return h(
    "div",
    { class: "link" },
    h("a", { href, rel: "noopener noreferrer", target }, caption)
  );
}

export function px(px: number) {
  return `${px}px`;
}

export function centeredFlex(content: any) {
  return h(
    "div",
    {
      style: {
        padding: "1px !important",
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-around",
      },
    },
    content
  );
}

export function confirm(action: string, phrase: string) {
  const confirm = window.prompt(
    `Are you sure you want to ${action} ? Type "${phrase}" to confirm.`
  );

  return confirm === phrase;
}

export function setLocal(key: string, value: any) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function getLocal(key: string, def: any) {
  const stored = localStorage.getItem(key);

  if (stored !== null && stored !== undefined) {
    try {
      const value = JSON.parse(stored);
      return value;
    } catch (err: any) {
      return def;
    }
  } else {
    return def;
  }
}

export function isAdmin() {
  return getLocal("IS_ADMIN", false);
}
