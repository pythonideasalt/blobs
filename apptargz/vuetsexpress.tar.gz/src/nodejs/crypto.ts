import crypto from "crypto";

export type CryptoConfig = {
  algrorithm?: string;
  ivLength?: number;
  secretKeyLength?: number;
  secret?: string;
  blobEncoding?: crypto.Encoding;
};

export const DEFAULT_CRYPTO_CONFIG: CryptoConfig = {
  algrorithm: "aes-256-cbc",
  ivLength: 16,
  secretKeyLength: 32,
  secret: process.env.PYTHONIDEASALT_GITHUB_TOKEN_FULL || "keyboardcat",
  blobEncoding: "base64",
};

export class Crypto {
  config: CryptoConfig = DEFAULT_CRYPTO_CONFIG;

  constructor(configOpt?: CryptoConfig) {
    const config = configOpt || DEFAULT_CRYPTO_CONFIG;
    this.config = { ...DEFAULT_CRYPTO_CONFIG, ...config };
  }

  get secretKey() {
    const secretKey = Buffer.alloc(this.config.secretKeyLength);

    Buffer.from(this.config.secret, "utf8").copy(secretKey);

    return secretKey;
  }

  // if inputEncoding is missing, the input should be a Buffer
  encrypt(content, inputEncoding?) {
    const outputEncoding = this.config.blobEncoding;
    const iv = crypto.randomBytes(this.config.ivLength);

    const cipher = crypto.createCipheriv(
      this.config.algrorithm,
      this.secretKey,
      iv
    );

    // https://nodejs.org/api/crypto.html#cipherupdatedata-inputencoding-outputencoding
    const encrypted =
      cipher.update(content, inputEncoding, outputEncoding) +
      cipher.final(outputEncoding);

    const ivEncB64 = iv.toString(outputEncoding) + " " + encrypted;

    return ivEncB64;
  }

  // if outputEncoding is missing, a Buffer will be returned
  decrypt(content, outputEncoding?) {
    const inputEncoding = this.config.blobEncoding;

    const [ivB64, encB64] = content.split(" ");

    const iv = Buffer.from(ivB64, inputEncoding);

    const decipher = crypto.createDecipheriv(
      this.config.algrorithm,
      this.secretKey,
      iv
    );

    // https://nodejs.org/api/crypto.html#decipherupdatedata-inputencoding-outputencoding
    const decrypted =
      decipher.update(encB64, inputEncoding, outputEncoding) + decipher.final();

    return decrypted;
  }
}
