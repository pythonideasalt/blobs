import { Db, Collection } from "./mongodb";
import { Router } from "./utils";
import { SseServer } from "./sse";
import _ from "lodash";
import { User } from "../shared/models";

export type ChessSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Chess {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  analysisColl: Collection;

  constructor(cs: ChessSetup) {
    this.appDb = cs.appDb;
    this.api = cs.api;
    this.sseServer = cs.sseServer;
    this.analysisColl = this.appDb.collection("analysis", {});

    this.mount();
  }

  mount() {
    this.api.postAuth("/storeanalysis", (req: any, res: any) => {
      const id = req.user.userId;

      this.analysisColl
        .setDocById(id, { game: req.body.game })
        .then((result) => {
          res.json(result);
        });
    });

    this.api.postAuth("/getanalysis", (req: any, res: any) => {
      const id = req.user.userId;

      this.analysisColl.getDocById(id, "lr").then((result) => {
        if (result) {
          res.json(result);
        } else {
          res.json({ game: false });
        }
      });
    });

    return this;
  }
}
