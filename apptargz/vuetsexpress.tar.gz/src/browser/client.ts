import {
  createApp,
  defineComponent,
  h,
  onMounted,
  reactive,
} from "vue/dist/vue.esm-browser.prod";
import { hotReload, post, setLogger } from "./api";
import { link, centeredFlex, confirm, globalReact } from "./misc";

import OauthWidget from "./oauthwidget";
import { ConfigNode } from "./configeditor";
import { Tabs } from "./tabs";
import { EventConsumer } from "./sse";
import { WebLogger } from "./logger";
import { CHAT_MESSAGE_MAX_LENGTH } from "../shared/config";
import { Board } from "./board";
import { randomQuote } from "../shared/quotes";
import { CreateSeek, ShowSeek } from "./createseek";
import { Seek } from "../shared/models";

const logger = new WebLogger();
setLogger(logger.logger);

const conf = new ConfigNode("config");

const react = reactive({
  activeUsers: [],
  messages: [],
  header: "",
  seeks: [],
});

function setQuote() {
  const [quote, by] = randomQuote(150, 40);
  react.header = `" ${quote} " <span style="font-weight:bold; color:#0f0;">${by}</span>`;
}

setInterval(() => {
  setQuote();
}, 30000);

setQuote();

function setSeeks(ev: any) {
  react.seeks = ev.seeks.map((s: any) => new Seek(s));
}

function delSeek(s: Seek) {
  post("msg", s.serialize()).then((result: any) => {
    if (result.error) {
      window.alert(result.error);
    }
  });
}

const ec = new EventConsumer({
  logger: logger.logger,
  eventCallback: (ev: any) => {
    if (ev.kind === "activeusers") {
      react.activeUsers = ev.activeUsers;

      return;
    }

    if (ev.kind === "chat") {
      react.messages = ev.messages;

      return;
    }

    if (ev.kind === "seeks") {
      setSeeks(ev);

      return;
    }
  },
}).mount();

let tabsBlob = [
  { caption: "Analysis", id: "analysisboard" },
  { caption: "Profile", id: "profile" },
];

if (globalReact.isAdmin) {
  tabsBlob = tabsBlob.concat([]);
}

const tabs = new Tabs("contentmiddle", [
  { caption: "Analysis", id: "analysisboard", icon: "search" },
  {
    caption: "Profile",
    id: "profile",
    icon: "profile",
    iconbutton: "iconbutton2",
  },
  { caption: "Seek", id: "createseek" },
  { caption: "Config", id: "config", adminOnly: true },
  { caption: "Logs", id: "logs", adminOnly: true },
]);

const config = h(
  conf.defineComponent(),
  {
    onUpload: (ev: any) => {
      post("setconfig", { config: conf.serialize(conf) }).then((result) => {
        //logger.log("log", JSON.stringify({setconfig: result}, null, 2));
        window.alert(JSON.stringify(result));
      });
    },
  },
  []
);

const analysisBoard = new Board();
const analysisboard = h(analysisBoard.defineComponent());

const logs = h(logger.defineComponent());

const profile = h("div", { class: "profile" }, [
  h(
    "button",
    {
      class: "login",
      onClick: () => {
        const token = window.prompt("Token");
        if (token) {
          localStorage.setItem("USER_TOKEN", `${token}`);
          document.location.reload();
        }
      },
    },
    "Login With Token"
  ),
  h(
    "button",
    {
      class: "reveal",
      onClick: () => {
        window.alert(localStorage.getItem("USER_TOKEN"));
      },
    },
    "Reveal Token"
  ),
]);

const createSeek = new CreateSeek();
const createseek = h(createSeek.defineComponent());

const contentMiddle = {
  analysisboard,
  profile,
  createseek,
  config,
  logs,
};

const index = defineComponent({
  setup() {
    onMounted(() => {
      post("getglobalconfig").then((result: any) => {
        //logger.log("log", JSON.stringify({getglobalconfig: result}, null, 2))
        conf.setFromBlob(result.content);
      });
      post("getactiveusers").then((result: any) => {
        const activeUsers = result.activeUsers;
        if (Array.isArray(activeUsers)) {
          react.activeUsers = result.activeUsers;
        }
      });
      post("getchat").then((result: any) => {
        react.messages = result.messages;
      });
      post("getseeks").then((result: any) => {
        setSeeks(result);
      });
    });
    return () => {
      const indexNode = h("div", { class: "app" }, [
        h("div", { class: "grid" }, [
          h(
            "div",
            { class: "topheader" },
            centeredFlex(
              h("div", { style: { color: "#ff0" }, innerHTML: react.header })
            )
          ),
          h("div", { class: ["header", "left"] }, centeredFlex("header left")),
          h("div", { class: ["header", "middle"] }, h(tabs.defineComponent())),
          h(
            "div",
            { class: ["header", "right"] },
            h(OauthWidget, { logger: logger.logger })
          ),
          h(
            "div",
            { class: ["content", "left", "top"] },
            h(
              "div",
              {},
              react.activeUsers.map((user: any) =>
                h("div", { class: "activeuser" }, user.username)
              )
            )
          ),
          h("div", { class: ["content", "left", "bottom"] }, [
            h(
              "div",
              {
                class: "chatmessages",
                onClick: (ev: any) => {
                  if (
                    ev.ctrlKey &&
                    confirm("delete the complete chat", "del")
                  ) {
                    post("deletechat", {}).then((result: any) => {
                      if (result.error) {
                        //window.alert(result.error);
                      }
                    });
                  }
                },
              },
              react.messages
                .slice()
                .reverse()
                .map((message: any) =>
                  h("div", {}, [
                    h("div", { class: "username" }, message.user.username),
                    h(
                      "div",
                      {
                        class: "message",
                        onClick: (ev: any) => {
                          ev.stopPropagation();
                          if (
                            ev.ctrlKey &&
                            confirm(
                              `delete message < ${message.message} >`,
                              "del"
                            )
                          ) {
                            ev.stopPropagation();

                            post("deletemessage", { id: message.id }).then(
                              (result: any) => {
                                if (result.error) {
                                  //window.alert(result.error);
                                }
                              }
                            );
                          }
                        },
                      },
                      message.message
                    ),
                  ])
                )
            ),
            h("input", {
              class: "chatinput",
              type: "text",
              maxlength: CHAT_MESSAGE_MAX_LENGTH,
              onKeyup: (ev: any) => {
                if (ev.keyCode === 13) {
                  const message = ev.target.value;
                  ev.target.value = "";
                  post("chat", { message }).then((result: any) => {
                    if (result.error) {
                      window.alert(result.error);
                    }
                  });
                }
              },
            }),
          ]),
          h(
            "div",
            { class: ["content", "middle"] },
            ["logs", "createseek", "config", "profile"].includes(
              tabs.effSelectedTabId()
            )
              ? (contentMiddle as any)[tabs.effSelectedTabId()]
              : centeredFlex((contentMiddle as any)[tabs.effSelectedTabId()])
          ),
          h(
            "div",
            { class: ["content", "right", "top"] },
            react.seeks.map((s: any) =>
              h(new ShowSeek(s).setOnClick(() => delSeek(s)).defineComponent())
            )
          ),
          h(
            "div",
            { class: ["content", "right", "bottom"] },
            centeredFlex("content right bottom")
          ),
          h("div", { class: ["footer", "left"] }, centeredFlex("footer left")),
          h(
            "div",
            { class: ["footer", "middle"] },
            centeredFlex("footer middle")
          ),
          h(
            "div",
            { class: ["footer", "right"] },
            centeredFlex("footer right")
          ),
          h(
            "div",
            { class: "bottomfooter" },
            centeredFlex([
              link(
                "https://github.com/pythonideasalt/vuetsexpress",
                "Source on GitHub"
              ),
              globalReact.isAdmin ? link("/man", "Manager") : undefined,
            ])
          ),
        ]),
      ]);
      return indexNode;
    };
  },
  template: "index",
});

const app = createApp(index);

app.mount("#app");

hotReload();
