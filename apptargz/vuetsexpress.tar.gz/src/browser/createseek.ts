import {
  SUPPORTED_TIME_CONTROLS,
  DEFAULT_TIME_CONTROL,
} from "../shared/cconfig";
import {
  DEFAULT_VARIANT,
  DEFAULT_RATED,
  ALLOWED_ROUNDS,
  DEFAULT_ROUNDS,
} from "../shared/config";
import { ALLOWED_VARIANTS, Seek } from "../shared/models";

import { h, reactive, defineComponent } from "vue/dist/vue.esm-browser.prod";
import { Labeled } from "./misc";

export class CreateSeek {
  react = reactive({
    variant: DEFAULT_VARIANT,
    tcId: DEFAULT_TIME_CONTROL.id,
    rated: DEFAULT_RATED,
    rounds: DEFAULT_ROUNDS,
  });

  constructor() {}

  renderFunction() {
    return h("div", { class: "createseek" }, [
      h("div", { class: "controls" }, [
        Labeled(
          "Variant",
          h(
            "select",
            {
              style: { color: "#007" },
              onChange: (ev: any) => {
                this.react.variant = ev.target.value;
              },
            },
            ALLOWED_VARIANTS.map((v) =>
              h(
                "option",
                {
                  value: v.chessopsKey,
                  selected: v.chessopsKey === this.react.variant,
                },
                v.displayName
              )
            )
          )
        ),
        Labeled(
          "Time Control",
          h(
            "select",
            {
              style: { color: "#070", "font-weight": "bold" },
              onChange: (ev: any) => {
                this.react.tcId = ev.target.value;
              },
            },
            SUPPORTED_TIME_CONTROLS.map((tc) =>
              h(
                "option",
                { value: tc.id, selected: tc.id === this.react.tcId },
                tc.display()
              )
            )
          )
        ),
        Labeled(
          "Rounds",
          h(
            "select",
            {
              style: { color: "#700" },
              onChange: (ev: any) => {
                this.react.rounds = ev.target.value;
              },
            },
            ALLOWED_ROUNDS.map((r) =>
              h("option", { value: r, selected: this.react.rounds === r }, r)
            )
          )
        ),
        Labeled(
          "Rated",
          h("input", {
            onChange: (ev: any) => {
              this.react.rated = ev.target.checked;
            },
            type: "checkbox",
            checked: this.react.rated,
          })
        ),
        h(
          "button",
          {
            class: "create",
            onClick: () => {
              const tc = SUPPORTED_TIME_CONTROLS.find(
                (tc) => tc.id === this.react.tcId
              );
              const seek = new Seek({
                variant: this.react.variant,
                tc,
                rated: this.react.rated,
                rounds: this.react.rounds,
              });
              window.alert(JSON.stringify(seek));
            },
          },
          "Create"
        ),
      ]),
    ]);
  }

  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        return self.renderFunction.bind(self);
      },
    });
  }
}
