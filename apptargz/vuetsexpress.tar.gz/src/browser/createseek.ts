import {
  SUPPORTED_TIME_CONTROLS,
  DEFAULT_TIME_CONTROL,
} from "../shared/cconfig";
import {
  DEFAULT_VARIANT_KEY,
  DEFAULT_RATED,
  ALLOWED_ROUNDS,
  DEFAULT_ROUNDS,
} from "../shared/config";
import { ALLOWED_VARIANTS, Seek, Variant } from "../shared/models";

import { h, reactive, defineComponent } from "vue/dist/vue.esm-browser.prod";
import { Labeled } from "./misc";

export class ShowSeek {
  seek = new Seek({});

  constructor(seek: Seek) {
    this.seek = seek;
  }

  renderFunction() {
    return h(
      "div",
      { class: "showseek" },
      h("div", { class: "cont" }, [
        h("div", { class: "variant" }, this.seek.variant.displayName),
        h("div", { class: "timecontrol" }, this.seek.tc.display()),
        h("div", { class: "rounds" }, this.seek.rounds),
        h("div", { class: "rated" }, this.seek.rated ? "Rated" : "Casual"),
      ])
    );
  }

  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        return self.renderFunction.bind(self);
      },
    });
  }
}

export class CreateSeek {
  react = reactive({
    variant: DEFAULT_VARIANT_KEY,
    tcId: DEFAULT_TIME_CONTROL.id,
    rated: DEFAULT_RATED,
    rounds: DEFAULT_ROUNDS,
    created: [],
  });

  constructor() {}

  renderFunction() {
    return h("div", { class: "createseek" }, [
      h("div", { class: "controls" }, [
        Labeled(
          "Variant",
          h(
            "select",
            {
              style: { color: "#007" },
              onChange: (ev: any) => {
                this.react.variant = ev.target.value;
              },
            },
            ALLOWED_VARIANTS.map((v) =>
              h(
                "option",
                {
                  value: v.chessopsKey,
                  selected: v.chessopsKey === this.react.variant,
                },
                v.displayName
              )
            )
          )
        ),
        Labeled(
          "Time Control",
          h(
            "select",
            {
              style: { color: "#070", "font-weight": "bold" },
              onChange: (ev: any) => {
                this.react.tcId = ev.target.value;
              },
            },
            SUPPORTED_TIME_CONTROLS.map((tc) =>
              h(
                "option",
                { value: tc.id, selected: tc.id === this.react.tcId },
                tc.display()
              )
            )
          )
        ),
        Labeled(
          "Rounds",
          h(
            "select",
            {
              style: { color: "#700" },
              onChange: (ev: any) => {
                this.react.rounds = ev.target.value;
              },
            },
            ALLOWED_ROUNDS.map((r) =>
              h("option", { value: r, selected: this.react.rounds === r }, r)
            )
          )
        ),
        Labeled(
          "Rated",
          h("input", {
            onChange: (ev: any) => {
              this.react.rated = ev.target.checked;
            },
            type: "checkbox",
            checked: this.react.rated,
          })
        ),
        h(
          "button",
          {
            class: "create",
            onClick: () => {
              const tc = SUPPORTED_TIME_CONTROLS.find(
                (tc) => tc.id === this.react.tcId
              );
              const seek = new Seek({
                variant: Variant.fromChessopsKey(this.react.variant),
                tc,
                rated: this.react.rated,
                rounds: this.react.rounds,
              });
              this.react.created.push(seek);
            },
          },
          "Create"
        ),
      ]),
      h("hr"),
      h(
        "div",
        {},
        this.react.created.map((cs: any) =>
          h(new ShowSeek(cs).defineComponent())
        )
      ),
    ]);
  }

  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        return self.renderFunction.bind(self);
      },
    });
  }
}
