import { Db, Collection } from "./mongodb";
import { Router, fetchJson } from "./utils";
import { SseServer } from "./sse";
import { randUserName } from "../shared/randusername";
import { uid, areStringArraysEqual } from "../shared/utils";
import { LOGIN_INTERVAL, CHECK_LICHESS_PROFILE_AFTER } from "./config";
import _ from "lodash";
import { User } from "../shared/models";

const lichessHost = "https://lichess.org";
const MAX_USERNAME_LENGTH = 20;

export type LoginSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Login {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  userIdsColl: Collection;
  usersColl: Collection;

  lastSeens: { [key: string]: number } = {};

  lastActives: string[] = [];

  debounceSendActiveUsersToAll = _.debounce(
    this.sendActiveUsers.bind(this),
    3000
  );

  constructor(ls: LoginSetup) {
    this.appDb = ls.appDb;
    this.api = ls.api;
    this.sseServer = ls.sseServer;
    this.userIdsColl = this.appDb.collection("userids", {
      onConnect: this.userIdsConnected.bind(this),
    });
    this.usersColl = this.appDb.collection("users", {
      onConnect: this.usersConnected.bind(this),
    });

    this.mount();
  }

  async userIdsConnected() {
    return;
    const userIds = await this.userIdsColl.getAll();
    console.log({ userIds });
  }

  async usersConnected() {
    return;
    const users = await this.usersColl.getAll();
    console.log({ users });
  }

  getActiveUserIds() {
    const now = Date.now();
    return Object.keys(this.lastSeens).filter(
      (userId) => now - this.lastSeens[userId] < 2 * LOGIN_INTERVAL
    );
  }

  getUsersByIds(ids: string[]) {
    return ids.map((id) => this.usersColl.docs[id]);
  }

  sendActiveUsersEvent() {
    const activeUsers = this.getUsersByIds(this.getActiveUserIds());

    const ev = {
      kind: "activeusers",
      activeUsers,
    };

    return ev;
  }

  sendActiveUsers() {
    this.sseServer.sendEventToAllConsumers(this.sendActiveUsersEvent());
  }

  checkActivesChanged() {
    const actives = this.getActiveUserIds();

    if (!areStringArraysEqual(actives, this.lastActives)) {
      console.log("active users changed");
      this.debounceSendActiveUsersToAll();
    }

    this.lastActives = actives;
  }

  setUser(res: any, blob: any) {
    blob.LOGIN_INTERVAL = LOGIN_INTERVAL;
    const userId = blob.userId;

    this.lastSeens[userId] = Date.now();

    this.checkActivesChanged();

    res.json(blob);
  }

  setRandUser(res: any) {
    const token = uid();
    const userId = uid();
    const username = randUserName(MAX_USERNAME_LENGTH);

    this.userIdsColl.setDocById(token, {
      userId,
    });

    const user = new User({
      userId,
      username,
    });

    this.usersColl.setDocById(userId, user.serialize());

    this.setUser(res, {
      userId,
      setUsername: username,
      setUserToken: token,
    });
  }

  getLichessAccount(token: string) {
    return new Promise(async (resolve) => {
      const accountResp = await fetchJson({
        url: `${lichessHost}/api/account`,
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (accountResp.ok) {
        const account = accountResp.json;

        if (account.error) {
          resolve({ error: account.error });
        } else {
          resolve({ account });
        }
      } else {
        resolve({ error: "Fetch Error" });
      }
    });
  }

  async login(req: any, res: any) {
    const token = req.body.token;
    //console.log("login with token", token);
    const existingToken = await this.userIdsColl.getDocById(token, "lr");
    //console.log("existing token", existingToken)

    if (existingToken) {
      const userId = existingToken.userId;

      const existingUser = await this.usersColl.getDocById(userId, "lr");
      //console.log("existing user", existingUser)

      if (existingUser) {
        const user = new User(existingUser);

        this.setUser(res, {
          userId,
          setUsername: existingUser.username,
        });

        if (user.lichessCheckedAt && !user.lichessProfile) return;

        if (Date.now() - user.lichessCheckedAt > CHECK_LICHESS_PROFILE_AFTER) {
          const account: any = await this.getLichessAccount(token);
          if (!account.error) {
            user.userId = userId;
            user.lichessProfile = account.account;
            this.usersColl.setDocById(userId, user.serialize());
          }
        }

        return;
      } else {
        console.error("fatal, token exists without user");

        this.setRandUser(res);

        return;
      }
    }

    const account: any = await this.getLichessAccount(token);

    if (account.error) {
      this.setRandUser(res);
    } else {
      const lichessProfile = account.account;

      const userId = lichessProfile.id;
      const username = lichessProfile.username;

      this.userIdsColl.setDocById(token, {
        userId,
      });

      const user = new User({
        userId,
        username,
        lichessCheckedAt: Date.now(),
        lichessProfile,
      });

      this.usersColl.setDocById(lichessProfile.id, user.serialize());

      this.setUser(res, {
        userId,
        setUsername: username,
      });
    }
  }

  checkLogin(req: any) {
    return new Promise(async (resolve) => {
      const token = req.body.token;
      const existingToken = await this.userIdsColl.getDocById(token, "lr");

      if (!existingToken) {
        resolve({ error: "Not Autherticated User", status: "token not found" });

        return;
      }

      const userId = existingToken.userId;
      const existingUser = await this.usersColl.getDocById(userId, "lr");

      if (!existingUser) {
        resolve({ error: "Not Autherticated User", status: "user not found" });

        return;
      }

      const user = new User(existingUser);

      resolve({ user });
    });
  }

  mount() {
    this.api.setCheckLogin(this.checkLogin.bind(this));

    this.api.post("/login", (req: any, res: any) => {
      this.login(req, res);
    });

    this.api.post("/getactiveusers", (req: any, res: any) => {
      res.json(this.sendActiveUsersEvent());
    });

    setInterval(this.checkActivesChanged.bind(this), LOGIN_INTERVAL / 2);

    return this;
  }
}
