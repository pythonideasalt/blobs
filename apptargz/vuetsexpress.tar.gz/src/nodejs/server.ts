import { GitHubAccountManager } from "./github";
const gitMan = new GitHubAccountManager();

import express from "express";
import path from "path";
import { envIntElse } from "./utils";
const app = express();
const PORT = envIntElse("PORT", 8080);
const APP_NAME = process.env.APP_NAME || "vuetsexpress";
const ADMIN_PASS = process.env.ADMIN_PASS;
const api: any = express.Router();
api.use(express.json());
app.use("/api", api);

const APP_DISPOSITION = process.env.APP_DISPOSITION || "prod";

const TIMESTAMP = Date.now();

api.postAdmin = function (endpoint: string, handler: any) {
  api.post("/" + endpoint, (req, res) => {
    if (req.body.ADMIN_PASS === ADMIN_PASS) {
      handler(req, res);
    } else {
      res.json({ endpoint, error: "Not Authorized" });
    }
  });
};

api.postAdmin("checkadmin", (req, res) => {
  res.json({ admin: true });
});

api.postAdmin("getconfig", (req, res) => {
  const acc = gitMan.getAccountByGitUserName("pythonideasalt");

  if (acc) {
    acc
      .getGitContentJsonDec("blobs", "config/vuetsexpress", {})
      .then((blob) => {
        res.json(blob);
      });
  } else {
    res.json(process.env);
  }
});

api.postAdmin("setconfig", (req, res) => {
  const acc = gitMan.getAccountByGitUserName("pythonideasalt");

  if (acc) {
    acc
      .upsertGitContentJsonEnc(
        "blobs",
        "config/vuetsexpress",
        req.body.config || {}
      )
      .then((result) => {
        res.json(result);
      });
  } else {
    res.json({ error: "GitHub Account Missing" });
  }
});

api.get("/timestamp", (req, res) => {
  res.json({ TIMESTAMP });
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "views", "index.html"));
});

app.get("/client.js", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "dist", "client.js"));
});

app.get("/client.js.map", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "dist", "client.js.map"));
});

app.get("/style.css", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "dist", "style.css"));
});

Promise.all([gitMan.init()]).then((initResult) => {
  console.log({ initResult });

  app.listen(PORT, () => {
    console.log(
      `< ${APP_NAME} > < ${APP_DISPOSITION} > listening on port < ${PORT} >`
    );
  });
});
