Sources that are intended to work in the browser execution context.
