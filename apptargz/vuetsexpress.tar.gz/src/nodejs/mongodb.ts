import { MongoClient } from "mongodb";
import { Logger } from "../shared/utils";

const DEFAULT_MONGODB_URI =
  process.env.MONGODB_URI || "mongodb://localhost:27017";

export type MongoConfig = {
  MONGODB_URI?: string;
  logger?: Logger;
};

export const DEFAULT_MONGO_CONFIG: MongoConfig = {
  MONGODB_URI: DEFAULT_MONGODB_URI,
  logger: new Logger({ owner: "mongoclient" }),
};

export class Client {
  config: MongoConfig = DEFAULT_MONGO_CONFIG;
  logger = new Logger({ owner: "mongoclient" });

  client: any = undefined;

  dbs: Db[] = [];

  constructor(configOpt?: MongoConfig) {
    if (configOpt) this.config = { ...DEFAULT_MONGO_CONFIG, ...configOpt };

    if (this.config.logger) {
      this.logger = this.config.logger;
    }

    const uri = this.config.MONGODB_URI || DEFAULT_MONGODB_URI;

    this.client = new MongoClient(uri, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    } as any);
  }

  listDbs() {
    return this.client.db().admin().listDatabases();
  }

  connect() {
    return new Promise((resolve) => {
      this.client.connect((err: any) => {
        if (err) {
          const report = {
            status: "MongoDb connection failed",
            error: err,
            success: false,
          };
          this.logger.log(report);
          resolve(report);
        } else {
          this.logger.log("MongoDb connected!");
          Promise.all(
            [this.listDbs()].concat(this.dbs.map((db) => db.onConnect()))
          ).then((result) => {
            resolve({
              error: false,
              success: true,
              onConnect: result.slice(1),
              dbs: JSON.stringify(
                result[0].databases.map((db: any) => db.name)
              ),
            });
          });
        }
      });
    });
  }

  db(name: string) {
    const db = new Db(name, this);
    this.dbs.push(db);
    return db;
  }
}

export type CollectionConfig = {};

export const DEFAULT_COLLECTION_CONFIG: CollectionConfig = {};

export class Collection {
  name: string;
  parentDb: Db;
  collection: any;
  config: CollectionConfig = DEFAULT_COLLECTION_CONFIG;
  docs: any[] = [];

  constructor(name: string, parentDb: Db, configOpt?: CollectionConfig) {
    this.name = name;
    this.parentDb = parentDb;
    this.collection = parentDb.db.collection(name);
    if (configOpt) this.config = { ...DEFAULT_COLLECTION_CONFIG, ...configOpt };
  }

  onConnect() {
    return new Promise((resolve) => {
      const report = { coll: this.name, connected: true };
      this.parentDb.parentClient.logger.log(report, "mongocoll");
      resolve(report);
    });
  }
}

export type DbConfig = {};

export const DEFAULT_DB_CONFIG: DbConfig = {};

export class Db {
  name: string;
  parentClient: Client;

  config: DbConfig = DEFAULT_DB_CONFIG;

  db: any;

  collections: Collection[] = [];

  constructor(name: string, parentClient: Client, configOpt?: DbConfig) {
    this.name = name;
    this.parentClient = parentClient;
    if (configOpt) this.config = { ...DEFAULT_DB_CONFIG, configOpt };
    this.db = this.parentClient.client.db(name);
  }

  collection(name: string, config?: any) {
    const coll = new Collection(name, this, config);
    this.collections.push(coll);
    return coll;
  }

  onConnect() {
    return new Promise((resolve) => {
      this.parentClient.logger.log(
        { db: this.name, connecting: true },
        "mongodb"
      );

      Promise.all(this.collections.map((coll) => coll.onConnect())).then(
        (result) => {
          resolve(result);
        }
      );
    });
  }
}
