import { Logger, LogItem } from "../shared/utils";

const API_BASE_URL = "/api";

let logger = new Logger();

export function setLogger(setLogger: any) {
  logger = setLogger;
}

function api(endpoint: string, method: string, payloadOpt?: any) {
  const payload = payloadOpt || {};
  const url = `${API_BASE_URL}/${endpoint}`;
  payload.ADMIN_PASS = localStorage.getItem("ADMIN_PASS");
  const headers = {
    "Content-Type": "application/json",
    Accept: "application/json",
  };
  if (endpoint !== "timestamp")
    logger.log(
      new LogItem(
        "api",
        "log",
        JSON.stringify(
          { sent: true, endpoint, method, payload, url, headers },
          null,
          2
        )
      )
    );
  return new Promise((resolve) => {
    fetch(url, {
      method,
      headers,
      body: method === "GET" ? undefined : JSON.stringify(payload),
    })
      .then((response) => {
        response
          .json()
          .then((json) => {
            if (endpoint !== "timestamp")
              logger.log(
                new LogItem(
                  "api",
                  "log",
                  JSON.stringify({ received: true, endpoint, json }, null, 2)
                )
              );
            resolve(json);
          })
          .catch((error) => {
            resolve({ error });
          });
      })
      .catch((error) => {
        resolve({ error });
      });
  });
}

export function get(endpoint: string, payload?: any) {
  return api(endpoint, "GET", payload);
}

export function post(endpoint: string, payload?: any) {
  return api(endpoint, "POST", payload);
}

export function hotReload() {
  get("timestamp").then((json: any) => {
    const TIMESTAMP = json.TIMESTAMP;

    setInterval(() => {
      get("timestamp").then((json: any) => {
        if (json.TIMESTAMP !== TIMESTAMP) {
          setTimeout(() => document.location.reload(), 3000);
        }
      });
    }, 1000);
  });
}
