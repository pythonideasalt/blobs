import { h, reactive } from "vue/dist/vue.esm-browser.prod";
import { post } from "./api";
import { JsonSerializable } from "../shared/models";

export const globalReact = reactive({
  isAdmin: false,
  username: "?",
});

export function alertJson(json: any) {
  window.alert(JSON.stringify(json));
}

export function setRemote(key: string, value: JsonSerializable | undefined) {
  return new Promise((resolve) => {
    post("setremotestorage", { key, value }).then((result: any) => {
      resolve(result);
    });
  });
}

export function getRemote(key: string, def: JsonSerializable | undefined) {
  return new Promise((resolve) => {
    post("getremotestorage", { key, def }).then((result: any) => {
      resolve(result);
    });
  });
}

export function link(href: string, captionOpt?: string, targetOpt?: string) {
  const caption = captionOpt || href;
  const target = targetOpt || "_blank";
  return h(
    "div",
    { class: "link" },
    h("a", { href, rel: "noopener noreferrer", target }, caption)
  );
}

export function px(px: number) {
  return `${px}px`;
}

export function centeredFlex(content: any) {
  return h(
    "div",
    {
      style: {
        padding: "1px !important",
        width: "100%",
        height: "100%",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-around",
      },
    },
    content
  );
}

export function confirm(action: string, phrase: string) {
  const confirm = window.prompt(
    `Are you sure you want to ${action} ? Type "${phrase}" to confirm.`
  );

  const confirmed = confirm === phrase;

  if (confirmed) return true;

  window.alert(`Canceled ${action} .`);

  return false;
}

export function setLocal(key: string, value: any) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function getLocal(key: string, def: any) {
  const stored = localStorage.getItem(key);

  if (stored !== null && stored !== undefined) {
    try {
      const value = JSON.parse(stored);
      return value;
    } catch (err: any) {
      return def;
    }
  } else {
    return def;
  }
}

export function Labeled(label: string, content: any) {
  return h("div", { class: "labeled" }, [
    h("div", { class: "cont" }, [
      h("div", { class: "label" }, label),
      h("div", { class: "content" }, content),
    ]),
  ]);
}

export function confirmButton(
  caption: string,
  action: string,
  phrase: string,
  callback: any
) {
  return h(
    "button",
    {
      onClick: () => {
        if (confirm(action, phrase)) callback();
      },
      class: "red",
    },
    caption
  );
}
