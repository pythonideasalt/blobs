import { h, reactive, defineComponent } from "vue/dist/vue.esm-browser.prod";

export type TabDescriptor = {
  caption: string;
  id: string;
};

export class Tabs {
  tabs: TabDescriptor[] = [];
  react = reactive({
    selectedTabId: "",
  });
  constructor(tabs: TabDescriptor[]) {
    this.tabs = tabs;
    if (this.tabs.length) {
      this.react.selectedTabId = this.tabs[0].id;
    }
  }
  renderFunction() {
    return h("div", { class: "tabs" }, [
      h(
        "div",
        { class: "cont" },
        this.tabs.map((tab) =>
          h(
            "div",
            {
              class: {
                tab: true,
                selected: this.react.selectedTabId === tab.id,
              },
              onClick: (ev: any) => {
                this.react.selectedTabId = tab.id;
              },
            },
            tab.caption
          )
        )
      ),
    ]);
  }
  defineComponent() {
    const self = this;
    return defineComponent({
      setup(props, context) {
        return self.renderFunction.bind(self);
      },
    });
  }
}
