import { getTransitionRawChildren } from "vue";
import { h, reactive, defineComponent } from "vue/dist/vue.esm-browser.prod";
import { setRemote, getRemote } from "./misc";

export type TabDescriptor = {
  caption: string;
  id: string;
};

export class Tabs {
  tabs: TabDescriptor[] = [];
  id: string;
  react = reactive({
    selectedTabId: "",
  });
  setDefaultSelectedTabId() {
    if (this.tabs.length) {
      this.react.selectedTabId = this.tabs[0].id;
    }
  }
  constructor(id: string, tabs: TabDescriptor[]) {
    this.id = id;
    this.tabs = tabs;
    this.setDefaultSelectedTabId();
    this.setFromRemote();
  }
  get selectedTabStorageId() {
    return "selectedtabid/" + this.id;
  }
  setFromRemote() {
    getRemote(this.selectedTabStorageId, this.react.selectedTabId).then(
      (result: any) => {
        if (result.error) {
        } else {
          this.react.selectedTabId = result.value;
        }
      }
    );
  }
  setSelectedTabId(tabId: string) {
    this.react.selectedTabId = tabId;
    setRemote(this.selectedTabStorageId, tabId).then((result: any) => {});
  }
  renderFunction() {
    return h("div", { class: "tabs" }, [
      h(
        "div",
        { class: "cont" },
        this.tabs.map((tab) =>
          h(
            "div",
            {
              class: {
                tab: true,
                selected: this.react.selectedTabId === tab.id,
              },
              onClick: (ev: any) => {
                this.setSelectedTabId(tab.id);
              },
            },
            tab.caption
          )
        )
      ),
    ]);
  }
  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        return self.renderFunction.bind(self);
      },
    });
  }
}
