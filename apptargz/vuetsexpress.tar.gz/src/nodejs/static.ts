import path from "path";

export class Static {
  app: any;

  constructor() {}

  sendView(res: any, name: string) {
    res.sendFile(path.join(__dirname, "..", "views", name));
  }

  sendModule(res: any, name: string) {
    res.sendFile(path.join(__dirname, "..", "node_modules", name));
  }

  mount(app: any) {
    this.app = app;

    this.app.get("/", (req: any, res: any) => {
      this.sendView(res, "index.html");
    });

    this.app.get("/man", (req: any, res: any) => {
      res.sendFile(path.join(__dirname, "..", "views", "man.html"));
    });

    this.app.get("/client.js", (req: any, res: any) => {
      res.sendFile(path.join(__dirname, "..", "dist", "client.js"));
    });

    this.app.get("/client.js.map", (req: any, res: any) => {
      res.sendFile(path.join(__dirname, "..", "dist", "client.js.map"));
    });

    this.app.get("/style.css", (req: any, res: any) => {
      res.sendFile(path.join(__dirname, "..", "dist", "style.css"));
    });

    this.app.get("/style.css.map", (req: any, res: any) => {
      res.sendFile(path.join(__dirname, "..", "dist", "style.css.map"));
    });

    this.app.get("/favicon.ico", (req: any, res: any) => {
      this.sendView(res, "favicon.ico");
    });

    this.app.get("/favicon.png", (req: any, res: any) => {
      this.sendView(res, "favicon.png");
    });

    this.app.get("/vue.js", (req: any, res: any) => {
      this.sendModule(res, "vue/dist/vue.global.prod.js");
    });

    this.app.get("/utils.js", (req: any, res: any) => {
      this.sendView(res, "utils.js");
    });
  }
}
