import { Db, Collection } from "./mongodb";
import { Router, fetchJson } from "./utils";
import { SseServer } from "./sse";
import _ from "lodash";

export type ChatSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Chat {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  messagesColl: Collection;

  debounceSendMessagesToAll = _.debounce(this.sendMessages.bind(this), 3000);

  constructor(cs: ChatSetup) {
    this.appDb = cs.appDb;
    this.api = cs.api;
    this.sseServer = cs.sseServer;
    this.messagesColl = this.appDb.collection("chat", {
      onConnect: this.messagesConnected.bind(this),
    });

    this.mount();
  }

  async messagesConnected() {
    await this.messagesColl.getAll();
  }

  sendMessagesEvent() {
    const ev = {
      kind: "chat",
      messages: this.messagesColl.docs,
    };

    return ev;
  }

  sendMessages() {
    this.sseServer.sendEventToAllConsumers(this.sendMessagesEvent());
  }

  chat(req: any, res: any) {}

  checkMessages() {}

  mount() {
    this.api.post("/chat", (req: any, res: any) => {
      this.chat(req, res);
    });

    this.api.post("/getchat", (req: any, res: any) => {
      res.json(this.sendMessagesEvent());
    });

    this.checkMessages();

    return this;
  }
}
