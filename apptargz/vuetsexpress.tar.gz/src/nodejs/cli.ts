import { GitHubAccountManager } from "./github";
import { HerokuAppManager } from "./heroku";

import fs from "fs";

const argv = require("minimist")(process.argv.slice(2));

const GITHUB_COMMANDS = ["uploadapptargz"];

const HEROKU_COMMANDS = ["deploy"];

const ALL_COMMANDS = [GITHUB_COMMANDS, HEROKU_COMMANDS].flat();

const UPLOAD_APPTARGZ_ACCOUNT = "pythonideasalt";

export function interpreter(argv) {
  return new Promise(async (resolve) => {
    const command = argv._[0];

    if (!ALL_COMMANDS.includes(command)) {
      resolve({ error: "unknown command" });
      return;
    }

    if (HEROKU_COMMANDS.includes(command)) {
      const appMan = new HerokuAppManager();

      const appManInitResult = await appMan.init();

      if (command === "deploy") {
        appMan.deployApp().then((result) => {
          resolve(result);
        });

        return;
      }
    }

    if (GITHUB_COMMANDS.includes(command)) {
      const gitMan = new GitHubAccountManager();

      const initGitManResult = await gitMan.init();

      if (command === "uploadapptargz") {
        const acc = gitMan.getAccountByGitUserName(UPLOAD_APPTARGZ_ACCOUNT);

        if (!acc) {
          resolve({ error: "upload apptargz account not available" });
          return;
        }

        let apptargz;

        try {
          apptargz = fs.readFileSync("repo.tar.gz");
        } catch (err) {
          resolve({ error: "could not open repo.tar.gz" });

          return;
        }

        const appName = argv.appName || "vuetsexpress";

        acc
          .upsertGitContent("blobs", `apptargz/${appName}.tar.gz`, apptargz)
          .then((result) => {
            resolve(result);
          });

        return;
      }
    }
  });
}

if (require.main === module) {
  interpreter(argv).then((result) => {
    console.log(result);
  });
}
