import {
  defineComponent,
  h,
  onMounted,
  reactive,
} from "vue/dist/vue.esm-browser.prod";

import { Chessground } from "@publishvue/chessground";
import { px } from "./misc";
import { uid } from "../shared/utils";
import { Game } from "../chessops";
import { post } from "./api";
import _ from "lodash";

export class Board {
  id = uid();
  board: any;
  react = reactive({
    size: 360,
  });
  game = Game().setVariant("atomic", undefined);
  debounceUpload = _.debounce(this.upload.bind(this), 3000);

  constructor() {}

  upload() {
    post("storeanalysis", { game: this.game.serialize() }).then(
      (result: any) => {
        if (result.error) {
          window.alert(result.error);
        }
      }
    );
  }

  renderFunction() {
    const innerContainer = h("div", {
      id: this.id,
      style: { width: px(this.react.size), height: px(this.react.size) },
      class: ["maplebackground", "is2d"],
    });

    const outerContainer = h(
      "div",
      { style: { width: px(this.react.size), height: px(this.react.size) } },
      [innerContainer]
    );

    const tobeginButton = h(
      "button",
      {
        class: "yellow",
        onClick: () => {
          this.game.toBegin();
          this.setUp();
        },
      },
      "|<"
    );
    const backButton = h(
      "button",
      {
        class: ["green", "wide"],
        onClick: () => {
          this.game.back();
          this.setUp();
        },
      },
      "<"
    );
    const forwardButton = h(
      "button",
      {
        class: ["green", "wide"],
        onClick: () => {
          this.game.forward();
          this.setUp();
        },
      },
      ">"
    );
    const toendButton = h(
      "button",
      {
        class: "yellow",
        onClick: () => {
          this.game.toEnd();
          this.setUp();
        },
      },
      ">|"
    );
    const delButton = h(
      "button",
      {
        class: "red",
        onClick: () => {
          this.game.del();
          this.setUp();
        },
      },
      "X"
    );
    const resetButton = h(
      "button",
      {
        class: "veryred",
        onClick: () => {
          this.game.setVariant("atomic", undefined);
          this.setUp();
        },
      },
      "R"
    );

    const controlsContainer = h("div", { class: "controlscont" }, [
      tobeginButton,
      backButton,
      forwardButton,
      toendButton,
      delButton,
      resetButton,
    ]);

    const vertContainer = h("div", { class: "vertcont" }, [
      outerContainer,
      controlsContainer,
    ]);

    const board = h("div", { class: "board" }, [vertContainer]);

    return board;
  }

  movePlayed(orig: string, dest: string) {
    const uci = orig + dest;

    const legals = this.game.pos.legalsForUci(uci);

    if (legals.length) {
      const playUci = legals[0];

      this.game.playUci(playUci);
    } else {
      window.alert("Illegal Move");
    }

    this.setUp();
  }

  makeBoard() {
    this.board = Chessground(document.getElementById(this.id) as any);

    this.board.set({
      movable: {
        events: {
          after: (orig: string, dest: string) => this.movePlayed(orig, dest),
        },
      },
    });
  }

  highlightMove(uci?: string) {
    if (!uci) {
      this.board.set({ lastMove: undefined });
    } else {
      this.board.set({
        lastMove: [uci.substring(0, 2), uci.substring(2, 4)],
      });
    }
  }

  setUp() {
    this.board.set({ fen: this.game.reportFen() });

    this.highlightMove(this.game.current.genUci);

    this.debounceUpload();
  }

  onResize() {
    this.react.size = Math.floor((window.innerHeight - 220) / 8) * 8;

    this.makeBoard();

    this.setUp();
  }

  onMounted() {
    this.makeBoard();

    window.addEventListener("resize", () => {
      this.onResize();
    });

    this.onResize();

    post("getanalysis", {}).then((result: any) => {
      if (result.error) {
        window.alert(result.error);
      } else if (result.game) {
        this.game.fromProps(result.game);

        this.setUp();
      }
    });
  }

  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        onMounted(() => {
          self.onMounted.bind(self)();
        });

        return self.renderFunction.bind(self);
      },
    });
  }
}
