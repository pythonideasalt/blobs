import { uid } from "./utils";

export class User {
  userId = "?";
  username = "?";
  lichessCheckedAt = 0;
  lichessProfile = undefined;

  constructor(blob: any) {
    this.deserialize(blob);
  }

  clone() {
    return new User(this.serialize());
  }

  cloneLight() {
    const user = this.clone();
    user.lichessProfile = undefined;
    return user;
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.userId = blob.userId || this.userId;
      this.username = blob.username || this.username;
      this.lichessCheckedAt = blob.lichessCheckedAt || 0;
      this.lichessProfile = blob.lichessProfile;
    }

    return this;
  }

  serialize() {
    return {
      userId: this.userId,
      username: this.username,
      lichessCheckedAt: this.lichessCheckedAt,
      lichessProfile: this.lichessProfile,
    };
  }
}

export class ChatMessage {
  id = uid();
  message = "message";
  createdAt = Date.now();
  user = new User({});

  constructor(blob: any) {
    this.deserialize(blob);
  }

  age() {
    return Date.now() - this.createdAt;
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.id = blob.id || this.id;
      this.message = blob.message || this.message;
      this.createdAt = blob.createdAt || this.createdAt;
      this.user = this.user.deserialize(blob.user);
    }

    return this;
  }

  serialize() {
    return {
      id: this.id,
      message: this.message,
      createdAt: this.createdAt,
      user: this.user.serialize(),
    };
  }
}
