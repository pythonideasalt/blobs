export const SSE_DEFAULT_DROP_DELAY = 120000;
export const SSE_DEFAULT_TICK_DELAY = 30000;

export function uid() {
  return (
    "uid_" + Date.now().toString(36) + Math.random().toString(36).substring(2)
  );
}
