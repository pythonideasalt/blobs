export const SSE_DEFAULT_RECONNECT_DELAY = 10000;
export const SSE_DEFAULT_DROP_DELAY = 120000;

import { uid } from "../shared/utils";

export type EventConsumer = {
  id: string;
  name: string;
  description: string;
  lastSeen: number;
  res: any;
};

export type SseSetup = {
  endpoint: string;
  reconnectDelay: number;
  dropDelay: number;
};

export const DEFAULT_SSE_SETUP: SseSetup = {
  endpoint: "events",
  reconnectDelay: SSE_DEFAULT_RECONNECT_DELAY,
  dropDelay: SSE_DEFAULT_DROP_DELAY,
};

export class SseServer {
  setup: SseSetup = DEFAULT_SSE_SETUP;
  consumers: EventConsumer[] = [];

  constructor(sseSetupOpt?: SseSetup) {
    if (sseSetupOpt) {
      this.setup = { ...DEFAULT_SSE_SETUP, ...sseSetupOpt };
    }
  }

  handler(req, res) {
    // register consumer
    const ec = {
      id: req.query.id || uid(),
      name: req.query.name || "anoneventconsumer",
      description: req.query.description || "unknowneventconsumer",
      lastSeen: Date.now(),
      res,
    };

    console.log("registered event consumer", ec.id);

    this.consumers.push(ec);

    // setup event source
    res.set({
      "Cache-Control": "no-cache",
      "Content-Type": "text/event-stream",
      Connection: "keep-alive",
    });

    res.flushHeaders();

    // tell the client to retry every this.setup.reconnectDelay seconds if connectivity is lost
    res.write(`retry: ${this.setup.reconnectDelay}\n\n`);

    // communicate ping delay to consumer
    this.sendEventRes(res, {
      kind: "setpingdelay",
      pingDelay: this.setup.dropDelay / 2,
    });
  }

  sendEventRes(res, ev) {
    res.write(`data: ${JSON.stringify(ev)}\n\n`);
  }

  sendEventToSingleConsumer(ec: EventConsumer, ev) {
    this.sendEventRes(ec.res, ev);
  }

  sendEventToAllConsumers(ev) {
    this.consumers.forEach((ec) => this.sendEventToSingleConsumer(ec, ev));
  }

  checkDrop() {
    const now = Date.now();
    this.consumers = this.consumers.filter((ec) => {
      const elapsed = now - ec.lastSeen;
      const drop = elapsed > this.setup.dropDelay;
      return !drop;
    });
  }

  getConsumerById(id: string) {
    return this.consumers.find((ec) => ec.id === id);
  }

  pingHandler(req, res) {
    const id = req.query.id;

    if (!id) {
      res.json({ error: `no id submitted in query` });
      return;
    }

    const ec = this.getConsumerById(id);

    if (ec) {
      ec.lastSeen = Date.now();

      res.json({ pong: id });
    } else {
      res.json({ error: `no consumer registered with id ${id}` });
    }
  }

  mount(router) {
    router.get(`/${this.setup.endpoint}`, this.handler.bind(this));
    router.get(`/${this.setup.endpoint}/ping`, this.pingHandler.bind(this));

    setInterval(this.checkDrop.bind(this), this.setup.dropDelay);

    return this;
  }
}
