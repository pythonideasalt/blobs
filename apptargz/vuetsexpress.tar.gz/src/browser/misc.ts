import { defineComponent, h, onMounted } from "vue/dist/vue.esm-browser.prod";

export function link(href: string, captionOpt?: string, targetOpt?: string) {
  const caption = captionOpt || href;
  const target = targetOpt || "_blank";
  return h(
    "div",
    { class: "link" },
    h("a", { href, rel: "noopener noreferrer", target }, caption)
  );
}
