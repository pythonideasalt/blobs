import { GitHubAccountManager } from "./github";
const gitMan = new GitHubAccountManager();
import { HerokuAppManager } from "./heroku";
const appMan = new HerokuAppManager();

import express from "express";
import path from "path";
import { envIntElse } from "./utils";
const app = express();
const PORT = envIntElse("PORT", 8080);
const APP_NAME = process.env.APP_NAME || "vuetsexpress";
const ADMIN_PASS = process.env.ADMIN_PASS;
const api: any = express.Router();
api.use(express.json());
app.use("/api", api);

import { SseServer } from "./sse";
const eventsServer = new SseServer().mount(api);

const APP_DISPOSITION = process.env.APP_DISPOSITION || "prod";

const TIMESTAMP = Date.now();

api.postAdmin = function (endpoint: string, handler: any) {
  api.post("/" + endpoint, (req, res) => {
    if (req.body.ADMIN_PASS === ADMIN_PASS) {
      handler(req, res);
    } else {
      res.json({ endpoint, error: "Not Authorized" });
    }
  });
};

api.postAdmin("checkadmin", (req, res) => {
  res.json({ admin: true });
});

api.postAdmin("getglobalconfig", (req, res) => {
  const acc = gitMan.getAccountByGitUserName("pythonideasalt");

  if (acc) {
    acc
      .getGitContentJsonDec("blobs", "config/vuetsexpress", {})
      .then((blob) => {
        res.json(blob);
      });
  } else {
    res.json(process.env);
  }
});

api.postAdmin("setconfig", (req, res) => {
  const acc = gitMan.getAccountByGitUserName("pythonideasalt");

  if (acc) {
    acc
      .upsertGitContentJsonEnc(
        "blobs",
        "config/vuetsexpress",
        req.body.config || {}
      )
      .then((result) => {
        res.json(result);
      });
  } else {
    res.json({ error: "GitHub Account Missing" });
  }
});

api.get("/timestamp", (req, res) => {
  res.json({ TIMESTAMP });
});

app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "views", "index.html"));
});

app.get("/man", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "views", "man.html"));
});

app.get("/client.js", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "dist", "client.js"));
});

app.get("/client.js.map", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "dist", "client.js.map"));
});

app.get("/style.css", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "dist", "style.css"));
});

////////////////////////////////////////////////////////////////////
// legacy

api.use((req, res, next) => {
  req.isAdmin = false;
  if (req.body) {
    if (req.body.ADMIN_PASS === process.env.ADMIN_PASS) {
      req.isAdmin = true;
    }
  }
  next();
});

const utils = {
  sendJson(res, blob) {
    res.json(blob);
  },
  sendView(res, name) {
    res.sendFile(path.join(__dirname, "..", "views", name));
  },
  sendModule(res, name) {
    res.sendFile(path.join(__dirname, "..", "node_modules", name));
  },
};

api.post("/appman", (req, res) => {
  if (req.isAdmin) {
    appMan.init().then((result) => {
      utils.sendJson(res, appMan.serialize());
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/gitman", (req, res) => {
  if (req.isAdmin) {
    gitMan.init().then((result) => {
      utils.sendJson(res, gitMan.serialize());
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/allman", (req, res) => {
  if (req.isAdmin) {
    Promise.all([appMan.init(), gitMan.init()]).then((result) => {
      utils.sendJson(res, {
        appMan: appMan.serialize(),
        gitMan: gitMan.serialize(),
      });
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/createrepo", (req, res) => {
  if (req.isAdmin) {
    const acc = gitMan.getAccountByGitUserName(req.body.gitUserName);
    if (acc) {
      acc.createRepo(req.body).then((createResult) => {
        gitMan.init().then((result) => {
          utils.sendJson(res, {
            createResult,
            gitMan: gitMan.serialize(),
          });
        });
      });
    } else {
      utils.sendJson(res, { error: "No Such Account" });
    }
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/fork", (req, res) => {
  if (req.isAdmin) {
    const acc = gitMan.getAccountByGitUserName(req.body.gitUserName);
    if (acc) {
      acc.forkRepo(req.body.owner, req.body.name).then((forkResult) => {
        setTimeout(() => {
          gitMan.init().then((result) => {
            utils.sendJson(res, {
              forkResult,
              gitMan: gitMan.serialize(),
            });
          });
        }, 5000);
      });
    } else {
      utils.sendJson(res, { error: "No Such Account" });
    }
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/deleterepo", (req, res) => {
  if (req.isAdmin) {
    const acc = gitMan.getAccountByGitUserName(req.body.gitUserName);
    if (acc) {
      acc.deleteRepo(req.body.name).then((deleteResult) => {
        setTimeout(() => {
          gitMan.init().then((result) => {
            utils.sendJson(res, {
              deleteResult,
              gitMan: gitMan.serialize(),
            });
          });
        }, 5000);
      });
    } else {
      utils.sendJson(res, { error: "No Such Account" });
    }
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/getlogs", (req, res) => {
  if (req.isAdmin) {
    appMan.getLogs(req.body.app.name).then((result) => {
      utils.sendJson(res, result);
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/getbuilds", (req, res) => {
  if (req.isAdmin) {
    appMan.getBuilds(req.body.name).then((result) => {
      utils.sendJson(res, result);
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/getconfig", (req, res) => {
  if (req.isAdmin) {
    appMan.getConfig(req.body.name).then((result) => {
      utils.sendJson(res, result);
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

api.post("/setconfig", (req, res) => {
  if (req.isAdmin) {
    appMan.setConfig(req.body.name, req.body.config).then((result) => {
      utils.sendJson(res, result);
    });
  } else {
    utils.sendJson(res, { error: "Not Authorized" });
  }
});

app.get("/", (req, res) => {
  utils.sendView(res, "index.html");
});

app.get("/favicon.ico", (req, res) => {
  utils.sendView(res, "favicon.ico");
});

app.get("/favicon.png", (req, res) => {
  utils.sendView(res, "favicon.png");
});

app.get("/vue.js", (req, res) => {
  utils.sendModule(res, "vue/dist/vue.global.prod.js");
});

app.get("/utils.js", (req, res) => {
  utils.sendView(res, "utils.js");
});

////////////////////////////////////////////////////////////////////

Promise.all([gitMan.init()]).then((initResult) => {
  console.log({ initResult });

  app.listen(PORT, () => {
    console.log(
      `< ${APP_NAME} > < ${APP_DISPOSITION} > listening on port < ${PORT} >`
    );
  });
});
