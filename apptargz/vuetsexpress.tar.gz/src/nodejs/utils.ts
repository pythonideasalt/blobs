export function envIntElse(key: string, def: number): number {
  const stored = process.env[key];
  if (typeof stored === "undefined") {
    return def;
  }
  const parsed = parseInt(stored);
  if (isNaN(parsed)) {
    return def;
  }
  return parsed;
}
