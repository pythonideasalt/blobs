# vuetsexpress

Vue Ts Express.

A powerful web application framework using a **Vue 3 Composition API** client and an **Express** server, all written in **Typescript** and bundled using **Rollup.js**. The repo is configured as a **GitPod** Workspace to facilitate portable and straighforward development. The app can be deployed to **Heroku** from a **GitHub** uploaded tarball using its **CLI**.

Implements a **chess playing interface**.

## Env configuration

### `ADMIN_PASS`

Administrator password. Optional, defaults to `admin`. To login as administrator, use Ctrl + Login.

### `MONGODB_URI`

MongoDb connect URI. Required in production, optional in development ( GitPod workspace installs and runs MongoDb ), defaults to `mongodb://localhost:27017`.

### `PYTHONIDEASALT_GITHUB_TOKEN_FULL`

GitHub token with repo scope. Optional. Necessary for GitHub repo manager, for storing repo tart.gz at GitHub and fetching additonal app config from GitHub.

### `HEROKU_TOKEN_AESTHETICBOOKSHELF`

Heroku API token. Optional. Necessary for Heroku app manager, for deploying app from tar.gz blob stored at GitHub. Deployment only works if `PYTHONIDEASALT_GITHUB_TOKEN_FULL` is also set.

## [Open in GitPod](https://gitpod.io#https://github.com/pythonideasalt/vuetsexpress)

If you don't run a prebuild, tasks will fail to run for the first time, because yarn install will be yet in progress. Wait for the installation to finish, then in Build Server: bash, Build Client: bash, Build Style: bash and Dev Server: bash terminals press the up key to bring back the startup command and press ENTER.

To run a prebuild, create a project from the repo in GitPod dashboard and run a prebuild. If a prebuild is in place, the workspace will open without error for the first time and should open the app in a new tab. See also https://www.gitpod.io/blog/teams-and-projects#projects .

When auto opening the app in a new tab, your browser may complain about unwanted popup window, so allow popups for the app.