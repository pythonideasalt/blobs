import path from "path";

export class Static {
  app: any;

  constructor() {}

  sendView(res, name) {
    res.sendFile(path.join(__dirname, "..", "views", name));
  }

  sendModule(res, name) {
    res.sendFile(path.join(__dirname, "..", "node_modules", name));
  }

  mount(app) {
    this.app = app;

    this.app.get("/", (req, res) => {
      this.sendView(res, "index.html");
    });

    this.app.get("/man", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "views", "man.html"));
    });

    this.app.get("/client.js", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "dist", "client.js"));
    });

    this.app.get("/client.js.map", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "dist", "client.js.map"));
    });

    this.app.get("/style.css", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "dist", "style.css"));
    });

    this.app.get("/style.css.map", (req, res) => {
      res.sendFile(path.join(__dirname, "..", "dist", "style.css.map"));
    });

    this.app.get("/favicon.ico", (req, res) => {
      this.sendView(res, "favicon.ico");
    });

    this.app.get("/favicon.png", (req, res) => {
      this.sendView(res, "favicon.png");
    });

    this.app.get("/vue.js", (req, res) => {
      this.sendModule(res, "vue/dist/vue.global.prod.js");
    });

    this.app.get("/utils.js", (req, res) => {
      this.sendView(res, "utils.js");
    });
  }
}
