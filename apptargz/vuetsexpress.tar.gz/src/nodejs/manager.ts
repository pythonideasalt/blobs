import { GitHubAccountManager } from "./github";
import { HerokuAppManager } from "./heroku";

const TIMESTAMP = Date.now();

export class Manager {
  api: any;

  gitMan: GitHubAccountManager = new GitHubAccountManager();
  appMan: HerokuAppManager = new HerokuAppManager();

  constructor() {}

  init() {
    return new Promise((resolve) => {
      Promise.all([this.appMan.init(), this.gitMan.init()]).then((result) => {
        resolve(result);
      });
    });
  }

  mount(api: any) {
    this.api = api;

    this.api.get("/timestamp", (req: any, res: any) => {
      res.json({ TIMESTAMP });
    });

    this.api.use((req: any, res: any, next: any) => {
      req.isAdmin = false;
      if (req.body) {
        if (req.body.ADMIN_PASS === process.env.ADMIN_PASS) {
          req.isAdmin = true;
        }
      }
      next();
    });

    this.api.postAdmin("checkadmin", (req: any, res: any) => {
      res.json({ admin: true });
    });

    this.api.postAdmin("getglobalconfig", (req: any, res: any) => {
      const acc = this.gitMan.getAccountByGitUserName("pythonideasalt");

      if (acc) {
        acc
          .getGitContentJsonDec("blobs", "config/vuetsexpress", {})
          .then((blob) => {
            res.json(blob);
          });
      } else {
        res.json(process.env);
      }
    });

    this.api.postAdmin("setconfig", (req: any, res: any) => {
      const acc = this.gitMan.getAccountByGitUserName("pythonideasalt");

      if (acc) {
        acc
          .upsertGitContentJsonEnc(
            "blobs",
            "config/vuetsexpress",
            req.body.config || {}
          )
          .then((result) => {
            res.json(result);
          });
      } else {
        res.json({ error: "GitHub Account Missing" });
      }
    });

    this.api.post("/appman", (req: any, res: any) => {
      if (req.isAdmin) {
        this.appMan.init().then((result) => {
          res.json(this.appMan.serialize());
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/gitman", (req: any, res: any) => {
      if (req.isAdmin) {
        this.gitMan.init().then((result) => {
          res.json(this.gitMan.serialize());
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/allman", (req: any, res: any) => {
      if (req.isAdmin) {
        Promise.all([this.appMan.init(), this.gitMan.init()]).then((result) => {
          res.json({
            appMan: this.appMan.serialize(),
            gitMan: this.gitMan.serialize(),
          });
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/createrepo", (req: any, res: any) => {
      if (req.isAdmin) {
        const acc = this.gitMan.getAccountByGitUserName(req.body.gitUserName);
        if (acc) {
          acc.createRepo(req.body).then((createResult) => {
            this.gitMan.init().then((result) => {
              res.json({
                createResult,
                gitMan: this.gitMan.serialize(),
              });
            });
          });
        } else {
          res.json({ error: "No Such Account" });
        }
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/fork", (req: any, res: any) => {
      if (req.isAdmin) {
        const acc = this.gitMan.getAccountByGitUserName(req.body.gitUserName);
        if (acc) {
          acc.forkRepo(req.body.owner, req.body.name).then((forkResult) => {
            setTimeout(() => {
              this.gitMan.init().then((result) => {
                res.json({
                  forkResult,
                  gitMan: this.gitMan.serialize(),
                });
              });
            }, 5000);
          });
        } else {
          res.json({ error: "No Such Account" });
        }
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/deleterepo", (req: any, res: any) => {
      if (req.isAdmin) {
        const acc = this.gitMan.getAccountByGitUserName(req.body.gitUserName);
        if (acc) {
          acc.deleteRepo(req.body.name).then((deleteResult) => {
            setTimeout(() => {
              this.gitMan.init().then((result) => {
                res.json({
                  deleteResult,
                  gitMan: this.gitMan.serialize(),
                });
              });
            }, 5000);
          });
        } else {
          res.json({ error: "No Such Account" });
        }
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/getlogs", (req: any, res: any) => {
      if (req.isAdmin) {
        this.appMan.getLogs(req.body.app.name).then((result) => {
          res.json(result);
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/getbuilds", (req: any, res: any) => {
      if (req.isAdmin) {
        this.appMan.getBuilds(req.body.name).then((result) => {
          res.json(result);
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/getconfig", (req: any, res: any) => {
      if (req.isAdmin) {
        this.appMan.getConfig(req.body.name).then((result) => {
          res.json(result);
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    this.api.post("/setconfig", (req: any, res: any) => {
      if (req.isAdmin) {
        this.appMan.setConfig(req.body.name, req.body.config).then((result) => {
          res.json(result);
        });
      } else {
        res.json({ error: "Not Authorized" });
      }
    });

    return this;
  }
}
