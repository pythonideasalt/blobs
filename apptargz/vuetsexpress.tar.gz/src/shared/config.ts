import { TimeControl } from "./models";

export const CHAT_MESSAGE_MAX_LENGTH = 200;
export const DEFAULT_VARIANT_KEY = "atomic";
export const DEFAUL_VARIANT_DISPLAY_NAME = "Atomic";
export const DEFAULT_VARIANT_ALIAS_REGEX = "atomic";
export const DEFAULT_RATED = true;
export const ALLOWED_ROUNDS = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
export const DEFAULT_ROUNDS = 2;
export const MAX_STORED_SEEKS = 20;
