import { Db, Collection } from "./mongodb";
import { Router, fetchJson } from "./utils";
import { SseServer } from "./sse";
import { AsyncComponentLoader } from "vue";
import { randUserName } from "../shared/randusername";

const lichessHost = "https://lichess.org";
const MAX_USERNAME_LENGTH = 30;

export type LoginSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Login {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  userIdsColl: Collection;
  usersColl: Collection;

  constructor(ls: LoginSetup) {
    this.appDb = ls.appDb;
    this.api = ls.api;
    this.sseServer = ls.sseServer;
    this.userIdsColl = this.appDb.collection("userids");
    this.usersColl = this.appDb.collection("users");

    this.mount();
  }

  setRandUser(res: any) {
    res.json({
      setUsername: randUserName(MAX_USERNAME_LENGTH),
    });
  }

  async login(req: any, res: any) {
    const token = req.body.token;
    console.log("login with token", token);
    const accountResp = await fetchJson({
      url: `${lichessHost}/api/account`,
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });
    if (accountResp.ok) {
      const account = accountResp.json;
      if (account.error) {
        this.setRandUser(res);
      } else {
        res.json({
          setUsername: account.username,
        });
      }
    } else {
      this.setRandUser(res);
    }
  }

  mount() {
    this.api.post("/login", (req: any, res: any) => {
      this.login(req, res);
    });

    return this;
  }
}
