import { getTransitionRawChildren } from "vue";
import { h, reactive, defineComponent } from "vue/dist/vue.esm-browser.prod";
import { setRemote, getRemote, globalReact } from "./misc";

export type TabDescriptor = {
  caption: string;
  id: string;
  adminOnly?: boolean;
};

export class Tabs {
  tabs: TabDescriptor[] = [];
  id: string;
  react = reactive({
    selectedTabId: "",
  });
  setDefaultSelectedTabId() {
    if (this.tabs.length) {
      this.react.selectedTabId = this.tabs[0].id;
    }
  }
  constructor(id: string, tabs: TabDescriptor[]) {
    this.id = id;
    this.tabs = tabs;
    this.setDefaultSelectedTabId();
    this.setFromRemote();
  }
  get selectedTabStorageId() {
    return "selectedtabid/" + this.id;
  }
  setFromRemote() {
    getRemote(this.selectedTabStorageId, this.react.selectedTabId).then(
      (result: any) => {
        const tabId = result.value;
        if (this.tabs.find((tab) => tab.id === tabId)) {
          this.react.selectedTabId = tabId;
        }
      }
    );
  }
  setSelectedTabId(tabId: string) {
    this.react.selectedTabId = tabId;
    setRemote(this.selectedTabStorageId, tabId).then((result: any) => {});
  }
  filteredTabs() {
    return this.tabs.filter((tab) => !tab.adminOnly || globalReact.isAdmin);
  }
  effSelectedTabId() {
    return this.filteredTabs().find(
      (tab) => tab.id === this.react.selectedTabId
    )
      ? this.react.selectedTabId
      : this.tabs.length
      ? this.tabs[0].id
      : undefined;
  }
  renderFunction() {
    return h("div", { class: "tabs" }, [
      h(
        "div",
        { class: "cont" },
        this.filteredTabs().map((tab, i) =>
          h(
            "div",
            {
              class: {
                tab: true,
                selected: this.effSelectedTabId() === tab.id,
              },
              onClick: (ev: any) => {
                this.setSelectedTabId(tab.id);
              },
            },
            tab.caption
          )
        )
      ),
    ]);
  }
  defineComponent() {
    const self = this;
    return defineComponent({
      setup() {
        return self.renderFunction.bind(self);
      },
    });
  }
}
