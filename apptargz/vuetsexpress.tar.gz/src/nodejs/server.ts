import express from "express";
import { envIntElse } from "./utils";
import { SseServer } from "./sse";
import { Client } from "./mongodb";
import { Static } from "./static";
import { Manager } from "./manager";

const PORT = envIntElse("PORT", 8080);
const APP_NAME = process.env.APP_NAME || "vuetsexpress";
const APP_DISPOSITION = process.env.APP_DISPOSITION || "prod";
const ADMIN_PASS = process.env.ADMIN_PASS;

const app = express();

const api: any = express.Router();

api.postAdmin = function (endpoint: string, handler: any) {
  api.post("/" + endpoint, (req: any, res: any) => {
    if (req.body.ADMIN_PASS === ADMIN_PASS) {
      handler(req, res);
    } else {
      res.json({ endpoint, error: "Not Authorized" });
    }
  });
};

api.use(express.json());
app.use("/api", api);

new Static().mount(app);

new SseServer().mount(api);

const manager = new Manager().mount(api);

const client = new Client();

////////////////////////////////////////////////////////////////////

Promise.all([manager.init(), client.connect()]).then((initResult) => {
  console.log({ initResult });

  app.listen(PORT, () => {
    console.log(
      `< ${APP_NAME} > < ${APP_DISPOSITION} > listening on port < ${PORT} >`
    );
  });
});
