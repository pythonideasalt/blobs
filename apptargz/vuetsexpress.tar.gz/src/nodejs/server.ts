import express from "express";
import { Router, envIntElse } from "./utils";
import { SseServer } from "./sse";
import { Client } from "./mongodb";
import { Static } from "./static";
import { Manager } from "./manager";
import { Login } from "./login";

const PORT = envIntElse("PORT", 8080);
const APP_NAME = process.env.APP_NAME || "vuetsexpress";
const APP_DISPOSITION = process.env.APP_DISPOSITION || "prod";

const app = express();

const router = new Router().mount("/", app);
const api = new Router().mount("/api", app);

new Static().mount(router);

const sseServer = new SseServer().mount(api);

const manager = new Manager().mount(api);

const client = new Client();

const appDb = client.db(APP_NAME);

const login = new Login({
  appDb,
  api,
  sseServer,
});

const testColl = appDb.collection("test");

async function dbTest() {
  /*await testColl.setDocById("doc1", { foo: "bar" });
  await testColl.setDocById("doc2", { bar: "baz" });*/
  const docs = await testColl.getAll();

  console.log({ docs });
}

////////////////////////////////////////////////////////////////////

const initItems: any[] = [];
//initItems.push(manager.init());
initItems.push(client.connect());

function init() {
  return new Promise((resolve) => {
    Promise.all(initItems)
      .then((initResult) => {
        resolve(initResult);
      })
      .catch((err) => {
        resolve({ error: err });
      });
  });
}

init().then((initResult) => {
  console.log({ initResult });

  dbTest();

  app.listen(PORT, () => {
    console.log(
      `< ${APP_NAME} > < ${APP_DISPOSITION} > listening on port < ${PORT} >`
    );
  });
});
