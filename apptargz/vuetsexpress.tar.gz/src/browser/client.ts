import {
  createApp,
  defineComponent,
  h,
  onMounted,
  reactive,
} from "vue/dist/vue.esm-browser.prod";
import { hotReload, post, setLogger } from "./api";
import { link } from "./misc";

import OauthWidget from "./oauthwidget";
import { ConfigNode } from "./configeditor";
import { Tabs } from "./tabs";
import { EventConsumer } from "./sse";
import { WebLogger } from "./logger";
import { CHAT_MESSAGE_MAX_LENGTH } from "../shared/config";
import { Board } from "./board";

const logger = new WebLogger();
setLogger(logger.logger);

const conf = new ConfigNode("config");

const react = reactive({
  activeUsers: [],
  messages: [],
});

const ec = new EventConsumer({
  logger: logger.logger,
  eventCallback: (ev: any) => {
    if (ev.kind === "activeusers") {
      react.activeUsers = ev.activeUsers;

      return;
    }

    if (ev.kind === "chat") {
      react.messages = ev.messages;

      return;
    }
  },
}).mount();

const tabs = new Tabs([
  { caption: "Analysis", id: "analysisboard" },
  { caption: "Config", id: "config" },
  { caption: "Logs", id: "logs" },
]);

const config = h(
  conf.defineComponent(),
  {
    onUpload: (ev: any) => {
      post("setconfig", { config: conf.serialize(conf) }).then((result) => {
        //logger.log("log", JSON.stringify({setconfig: result}, null, 2));
        window.alert(JSON.stringify(result));
      });
    },
  },
  []
);

const analysisBoard = new Board();
const analysisboard = h(analysisBoard.defineComponent());

const logs = h(logger.defineComponent());

const contentMiddle = {
  analysisboard,
  config,
  logs,
};

const index = defineComponent({
  setup() {
    onMounted(() => {
      post("getglobalconfig").then((result: any) => {
        //logger.log("log", JSON.stringify({getglobalconfig: result}, null, 2))
        conf.setFromBlob(result.content);
      });
      post("getactiveusers").then((result: any) => {
        const activeUsers = result.activeUsers;
        if (Array.isArray(activeUsers)) {
          react.activeUsers = result.activeUsers;
        }
      });
      post("getchat").then((result: any) => {
        react.messages = result.messages;
      });
    });
    return () => {
      const indexNode = h("div", { class: "app" }, [
        h("div", { class: "grid" }, [
          h("div", { class: "topheader" }, "topheader"),
          h("div", { class: ["header", "left"] }, "header left"),
          h("div", { class: ["header", "middle"] }, h(tabs.defineComponent())),
          h(
            "div",
            { class: ["header", "right"] },
            h(OauthWidget, { logger: logger.logger })
          ),
          h(
            "div",
            { class: ["content", "left", "top"] },
            h(
              "div",
              {},
              react.activeUsers.map((user: any) =>
                h("div", { class: "activeuser" }, user.username)
              )
            )
          ),
          h("div", { class: ["content", "left", "bottom"] }, [
            h(
              "div",
              {
                class: "chatmessages",
                onClick: (ev: any) => {
                  if (ev.ctrlKey) {
                    post("deletechat", {}).then((result: any) => {
                      if (result.error) {
                        window.alert(result.error);
                      }
                    });
                  }
                },
              },
              react.messages
                .slice()
                .reverse()
                .map((message: any) =>
                  h("div", {}, [
                    h("div", { class: "username" }, message.user.username),
                    h("div", { class: "message" }, message.message),
                  ])
                )
            ),
            h("input", {
              class: "chatinput",
              type: "text",
              maxlength: CHAT_MESSAGE_MAX_LENGTH,
              onKeyup: (ev: any) => {
                if (ev.keyCode === 13) {
                  const message = ev.target.value;
                  ev.target.value = "";
                  post("chat", { message }).then((result: any) => {
                    if (result.error) {
                      window.alert(result.error);
                    }
                  });
                }
              },
            }),
          ]),
          h(
            "div",
            { class: ["content", "middle"] },
            (contentMiddle as any)[tabs.react.selectedTabId]
          ),
          h("div", { class: ["content", "right", "top"] }, "content right top"),
          h(
            "div",
            { class: ["content", "right", "bottom"] },
            "content right bottom"
          ),
          h("div", { class: ["footer", "left"] }, "footer left"),
          h("div", { class: ["footer", "middle"] }, "footer middle"),
          h("div", { class: ["footer", "right"] }, "footer right"),
          h(
            "div",
            { class: "bottomfooter" },
            link(
              "https://github.com/pythonideasalt/vuetsexpress",
              "Source on GitHub"
            ),
            h("text", {}, "|"),
            link("/man", "Manager")
          ),
        ]),
      ]);
      return indexNode;
    };
  },
  template: "index",
});

const app = createApp(index);

app.mount("#app");

hotReload();
