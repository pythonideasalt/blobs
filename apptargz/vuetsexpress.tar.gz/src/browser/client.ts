import {
  createApp,
  defineComponent,
  h,
  onMounted,
} from "vue/dist/vue.esm-browser.prod";
import { hotReload, post } from "./api";

import OauthWidget from "./oauthwidget";
import { ConfigNode } from "./configeditor";
import { Tabs } from "./tabs";

const conf = new ConfigNode("config");

const tabs = new Tabs([
  { caption: "Config", id: "config" },
  { caption: "Dummy", id: "dummy" },
]);

const config = h(
  conf.defineComponent(),
  {
    onUpload: (ev) => {
      post("setconfig", { config: conf.serialize(conf) }).then((result) => {
        console.log(result);
        window.alert(JSON.stringify(result));
      });
    },
  },
  []
);

const dummy = h("div", {}, "dummy");

const contentMiddle = {
  config,
  dummy,
};

const index = defineComponent({
  setup(props, context) {
    onMounted(() => {
      post("checkadmin").then((result) => {
        console.log(result);
      });
      post("getglobalconfig").then((result: any) => {
        console.log(result);
        conf.setFromBlob(result.content);
      });
    });
    return () => {
      const indexNode = h("div", { class: "app" }, [
        h("div", { class: "grid" }, [
          h("div", { class: "topheader" }, "topheader"),
          h("div", { class: ["header", "left"] }, "header left"),
          h("div", { class: ["header", "middle"] }, h(tabs.defineComponent())),
          h("div", { class: ["header", "right"] }, h(OauthWidget)),
          h("div", { class: ["content", "left", "top"] }, "content left top"),
          h(
            "div",
            { class: ["content", "left", "bottom"] },
            "content left bottom"
          ),
          h(
            "div",
            { class: ["content", "middle"] },
            contentMiddle[tabs.react.selectedTabId]
          ),
          h("div", { class: ["content", "right", "top"] }, "content right top"),
          h(
            "div",
            { class: ["content", "right", "bottom"] },
            "content right bottom"
          ),
          h("div", { class: ["footer", "left"] }, "footer left"),
          h("div", { class: ["footer", "middle"] }, "footer middle"),
          h("div", { class: ["footer", "right"] }, "footer right"),
          h(
            "div",
            { class: "bottomfooter" },
            h(
              "a",
              { href: "/man", rel: "noopener noreferrer", target: "_blank" },
              "Manager"
            )
          ),
        ]),
      ]);
      return indexNode;
    };
  },
  template: "index",
});

const app = createApp(index);

app.mount("#app");

hotReload();
