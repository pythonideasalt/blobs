import { envIntElse, envBlobElse } from "./utils";
import { DAY, WEEK, SECOND, MINUTE, HOUR, TimeQuota } from "../shared/time";

export const LOGIN_INTERVAL = envIntElse("LOGIN_INTERVAL", 60000);
export const CHECK_LICHESS_PROFILE_AFTER = DAY;
export const DISCARD_CHAT_MESSAGE_AFTER = WEEK;

export const CHAT_TIME_QUOTA = new TimeQuota().fromBlob(
  envBlobElse("CHAT_TIME_QUOTA", {
    name: "Chat",
    items: [
      { dur: 5 * SECOND, freq: 1 },
      { dur: 1 * MINUTE, freq: 5 },
      { dur: 1 * HOUR, freq: 100 },
      { dur: 1 * DAY, freq: 500 },
    ],
  })
);
