import { Oauth } from "./oauth";

import { defineComponent, h, onMounted } from "vue/dist/vue.esm-browser.prod";

function setAdminPass() {
  const pass = window.prompt("Admin Pass");

  if (pass) {
    localStorage.setItem("ADMIN_PASS", pass);
  }

  document.location.reload();
}

export default defineComponent({
  props: {
    username: {
      type: String,
      default: "?",
    },
  },
  setup(props, context) {
    const oauth = new Oauth();

    onMounted(async () => {
      await oauth.init();

      const account: any = await oauth.account();

      if (typeof account === "object" && account.username) {
        props.username = account.username;
      }
    });

    return () => {
      return h("div", { class: "oauthwidget" }, [
        h("div", { class: "cont" }, [
          h(
            "button",
            {
              onClick: (ev: any) => {
                if (ev.ctrlKey) {
                  setAdminPass();
                } else {
                  oauth.login();
                }
              },
            },
            "Login"
          ),
          h(
            "button",
            {
              onClick: () => {
                oauth.logout();
              },
            },
            "Logout"
          ),
          h("div", { class: "username" }, props.username),
        ]),
      ]);
    };
  },
});
