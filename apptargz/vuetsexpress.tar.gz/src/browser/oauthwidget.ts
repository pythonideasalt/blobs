import { Oauth } from "./oauth";
import { post } from "./api";
import {
  defineComponent,
  h,
  onMounted,
  onBeforeUnmount,
  reactive,
  ref,
  nextTick,
} from "vue/dist/vue.esm-browser.prod";
import { Logger } from "../shared/utils";
import { alertJson, globalReact } from "./misc";
import { Serializable, User } from "../shared/models";
import { DEFAULT_LOGIN_INTERVAL } from "../shared/config";

function setAdminPass() {
  const pass = window.prompt("Admin Pass");

  if (pass) {
    localStorage.setItem("ADMIN_PASS", pass);
  }

  document.location.reload();
}

export default defineComponent({
  props: {
    username: {
      type: String,
      default: "?",
    },
    logger: {
      type: Object,
      default: () => new Logger({ owner: "oauthwidget" }),
    },
    watch: {},
  },
  setup(props: any) {
    const oauth = new Oauth();
    const react = reactive({
      key: 0,
      admin: false,
      scale: 1,
    });
    const contRef = ref(0);

    function checkAdmin() {
      post("checkadmin").then((result: any) => {
        react.key++;
        if (result.error) {
          react.admin = false;
          globalReact.isAdmin = false;
        } else {
          react.admin = true;
          globalReact.isAdmin = true;
        }
        props.logger.log({ admin: !!react.admin }, "oauthwidgetcheckadmin");
      });
    }

    let loginInterval = DEFAULT_LOGIN_INTERVAL;

    function login() {
      post("login", { token: localStorage.getItem("USER_TOKEN") }).then(
        (result: any) => {
          //alertJson(result)
          const user = Serializable.fromBlob(result) as User;
          if (user) {
            globalReact.user = user;
            localStorage.setItem("USER_TOKEN", user.token);
            props.username = user.username;
            loginInterval = user.LOGIN_INTERVAL;
            props.logger.log({ login: user.serialize() }, "oauthwidgetlogin");
          }
        }
      );
    }

    let co: any, wo: any;

    onMounted(async () => {
      await oauth.init();

      login();

      checkAdmin();

      function scale() {
        const cw = props.watch._rawValue.clientWidth;
        const ww = contRef._rawValue.clientWidth;

        if (cw < ww) {
          react.scale = cw / ww;
        } else {
          react.scale = 1;
        }
      }

      nextTick(() => {
        // https://stackoverflow.com/questions/43813731/how-to-trigger-an-event-when-element-is-resized-in-vue-js
        co = new ResizeObserver(scale).observe(props.watch._rawValue);
        wo = new ResizeObserver(scale).observe(contRef._rawValue);
      });
    });

    onBeforeUnmount(() => {
      // https://stackoverflow.com/questions/43813731/how-to-trigger-an-event-when-element-is-resized-in-vue-js
      if (co) co.unobserve(props.watch._rawValue);
      if (wo) wo.unobserve(contRef._rawValue);
    });

    return () => {
      return h(
        "div",
        {
          class: "oauthwidget",
          style: { transform: `scale(${react.scale})` },
          key: react.key,
          ref: contRef,
          id: "contref",
        },
        [
          h("div", { class: "cont" }, [
            h(
              "button",
              {
                class: "login",
                onClick: (ev: any) => {
                  if (ev.ctrlKey) {
                    setAdminPass();
                  } else {
                    oauth.login();
                  }
                },
              },
              "Login"
            ),
            h(
              "button",
              {
                class: "logout",
                onClick: () => {
                  oauth.logout();
                },
              },
              "Logout"
            ),
            h("div", { class: "username" }, props.username),
            react.admin ? h("div", { class: "admin" }, "A") : undefined,
          ]),
        ]
      );
    };
  },
});
