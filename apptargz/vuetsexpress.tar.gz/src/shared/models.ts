import { uid } from "./utils";
import {
  DEFAULT_VARIANT_KEY,
  DEFAUL_VARIANT_DISPLAY_NAME,
  DEFAULT_VARIANT_ALIAS_REGEX,
  DEFAULT_RATED,
} from "./config";
import { upperFirst } from "lodash";

export const CHESSOPS_VARIANT_KEYS = [
  "chess",
  "antichess",
  "atomic",
  "crazyhouse",
  "horde",
  "kingofthehill",
  "racingkings",
  "3check",
] as const;

export type CHESSOPS_VARIANT_KEY = typeof CHESSOPS_VARIANT_KEYS[number];

export class Variant {
  chessopsKey: CHESSOPS_VARIANT_KEY = DEFAULT_VARIANT_KEY;
  displayName = "Variant";
  aliasRegex = "variant";

  static fromChessopsKey(chessopsKey: CHESSOPS_VARIANT_KEY) {
    return (
      ALLOWED_VARIANTS.find((v) => v.chessopsKey === chessopsKey) ||
      DEFAULT_VARIANT
    );
  }

  constructor(
    chessopsKey: CHESSOPS_VARIANT_KEY,
    displayName: string,
    aliasRegex: string
  ) {
    this.chessopsKey = chessopsKey;
    this.displayName = displayName;
    this.aliasRegex = aliasRegex;
  }

  serialize() {
    return {
      chessopsKey: this.chessopsKey,
      displayName: this.displayName,
    };
  }
}

export const DEFAULT_VARIANT = new Variant(
  DEFAULT_VARIANT_KEY,
  DEFAUL_VARIANT_DISPLAY_NAME,
  DEFAULT_VARIANT_ALIAS_REGEX
);

export const ALLOWED_VARIANTS = [
  new Variant("chess", "Standard", "^chess|standard"),
  new Variant("antichess", "Antichess", "^anti|giveaway|give away|loser"),
  DEFAULT_VARIANT,
  //new Variant("crazyhouse", "Crazyhouse", "crazy"),
  new Variant("horde", "Horde", "horde"),
  new Variant(
    "kingofthehill",
    "King of the Hill",
    "king of the hill|kingofthehill"
  ),
  new Variant("racingkings", "Racing Kings", "racing kings|racingkings"),
  new Variant("3check", "Three Check", "3check|three check|threecheck"),
];

export class User {
  userId = "?";
  username = "?";
  lichessCheckedAt = 0;
  lichessProfile = undefined;

  constructor(blob: any) {
    this.deserialize(blob);
  }

  clone() {
    return new User(this.serialize());
  }

  cloneLight() {
    const user = this.clone();
    user.lichessProfile = undefined;
    return user;
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.userId = blob.userId || this.userId;
      this.username = blob.username || this.username;
      this.lichessCheckedAt = blob.lichessCheckedAt || 0;
      this.lichessProfile = blob.lichessProfile;
    }

    return this;
  }

  serialize() {
    return {
      userId: this.userId,
      username: this.username,
      lichessCheckedAt: this.lichessCheckedAt,
      lichessProfile: this.lichessProfile,
    };
  }
}

export class ChatMessage {
  id = uid();
  message = "message";
  createdAt = Date.now();
  user = new User({});

  constructor(blob: any) {
    this.deserialize(blob);
  }

  age() {
    return Date.now() - this.createdAt;
  }

  deserialize(blob: any) {
    if (typeof blob === "object") {
      this.id = blob.id || this.id;
      this.message = blob.message || this.message;
      this.createdAt = blob.createdAt || this.createdAt;
      this.user = this.user.deserialize(blob.user);
    }

    return this;
  }

  serialize() {
    return {
      id: this.id,
      message: this.message,
      createdAt: this.createdAt,
      user: this.user.serialize(),
    };
  }
}

//////////////////////////////////////////////////////////

export type Blob = { [key: string]: any };

export const SERIALIZABLE_KINDS = ["timecontrol", "seek"] as const;

export type SERIALIZABLE_KIND = typeof SERIALIZABLE_KINDS[number];

export abstract class Serializable {
  kind: SERIALIZABLE_KIND;
  id = uid();
  createdAt = Date.now();

  static fromBlob(blob: Blob): Serializable | undefined {
    if (blob) {
      const kind = blob.kind as SERIALIZABLE_KIND;
      switch (kind) {
        case "timecontrol":
          return new TimeControl(blob);
        case "seek":
          return new Seek(blob);
        default:
          return undefined;
      }
    } else {
      return undefined;
    }
  }

  constructor(kind: SERIALIZABLE_KIND) {
    this.kind = kind;
  }

  abstract serializeFunc(): Blob;

  deserializeFunc(blob: Blob) {
    if (typeof blob === "object") {
      this.id = blob.id || this.id;
      this.createdAt = blob.createdAt || this.createdAt;
    }
  }

  abstract deserialize(blob: Blob): Serializable;

  serialize(): Blob {
    const blob = this.serializeFunc();

    blob.kind = this.kind;
    blob.id = this.id;
    blob.createdAt = this.createdAt;

    return blob;
  }
}

//////////////////////////////////////////////////////////

export class TimeControl extends Serializable {
  initial: number = 180;
  increment: number = 2;

  constructor(blob: Blob) {
    super("timecontrol");
    this.deserialize(blob);
  }

  display() {
    return `${this.initial / 60} + ${this.increment}`;
  }

  serializeFunc(): Blob {
    return {
      initial: this.initial,
      increment: this.increment,
    };
  }

  deserialize(blob: Blob): TimeControl {
    if (typeof blob === "object") {
      this.deserializeFunc(blob);
      this.initial = blob.initial || this.initial;
      if (blob.initial === 0) this.initial = 0;
      this.increment = blob.increment || this.increment;
      if (blob.increment === 0) this.increment = 0;
    }
    return this;
  }
}

export class Seek extends Serializable {
  user: User = new User({});
  tc: TimeControl = new TimeControl({});
  variant: Variant = DEFAULT_VARIANT;
  rounds = 1;
  rated: boolean = DEFAULT_RATED;

  constructor(blob: Blob) {
    super("seek");
    this.deserialize(blob);
  }

  deserialize(blob: Blob): Seek {
    if (typeof blob === "object") {
      this.deserializeFunc(blob);
      this.user = new User(blob.user);
      this.tc = new TimeControl(blob.tc);
      this.variant =
        Variant.fromChessopsKey(
          blob.variant?.chessopsKey || DEFAULT_VARIANT_KEY
        ) || this.variant;
      this.rounds = blob.rounds || this.rounds;
      this.rated = blob.rated || this.rated;
      if (blob.rated === false) this.rated = false;
    }
    return this;
  }

  serializeFunc(): Blob {
    return {
      user: this.user.cloneLight().serialize(),
      tc: this.tc.serialize(),
      variant: this.variant.serialize(),
      rounds: this.rounds,
      rated: this.rated,
    };
  }
}

//////////////////////////////////////////////////////////
