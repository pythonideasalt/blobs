import { GitHubAccountManager } from "./github";
import { HerokuAppManager } from "./heroku";
import { randUserName } from "../shared/randusername";

import fs from "fs";
import { compile } from "@vue/compiler-dom";

const argv = require("minimist")(process.argv.slice(2));

const GITHUB_COMMANDS = ["uploadapptargz", "configenv", "commits"];

const HEROKU_COMMANDS = ["deploy"];

const MISC_COMMANDS = ["randuser"];

const ALL_COMMANDS = [GITHUB_COMMANDS, HEROKU_COMMANDS, MISC_COMMANDS].flat();

const UPLOAD_APPTARGZ_ACCOUNT = "pythonideasalt";
const CONFIG_ACCOUNT = "pythonideasalt";
const APP_NAME = "vuetsexpress";

export function interpreter(argv: any) {
  return new Promise(async (resolve) => {
    const command = argv._[0];

    if (!ALL_COMMANDS.includes(command)) {
      resolve({ error: "unknown command" });
      return;
    }

    if (MISC_COMMANDS.includes(command)) {
      if (command === "randuser") {
        const limit = argv.limit ? parseInt(argv.limit) : 30;

        const randomUserName = randUserName(limit);

        resolve({ randomUserName });

        return;
      }
    }

    if (HEROKU_COMMANDS.includes(command)) {
      const appMan = new HerokuAppManager();

      const appManInitResult = await appMan.init();

      if (command === "deploy") {
        appMan.deployApp().then((result) => {
          resolve(result);
        });

        return;
      }
    }

    if (GITHUB_COMMANDS.includes(command)) {
      const gitMan = new GitHubAccountManager();

      const initGitManResult = await gitMan.init();

      if (command === "configenv") {
        const acc = gitMan.getAccountByGitUserName(CONFIG_ACCOUNT);

        if (!acc) {
          resolve({ stdout: "echo config account not available" });
          return;
        }

        acc
          .getGitContentJsonDec("blobs", `config/${APP_NAME}`, {})
          .then((blob: any) => {
            if (blob.content) {
              let stdout = "";
              for (const key in blob.content.heroku.token) {
                stdout += `export HEROKU_TOKEN_${key.toLocaleUpperCase()}="${
                  blob.content.heroku.token[key]
                }"\n`;
              }
              for (const key in blob.content.github.token) {
                stdout += `export ${key.toLocaleUpperCase()}_GITHUB_TOKEN_FULL="${
                  blob.content.github.token[key]
                }"\n`;
              }
              resolve({ stdout });
            } else {
              resolve({ stdout: "echo could not get config" });
            }
          });

        return;
      }

      if (command === "uploadapptargz") {
        const acc = gitMan.getAccountByGitUserName(UPLOAD_APPTARGZ_ACCOUNT);

        if (!acc) {
          resolve({ error: "upload apptargz account not available" });
          return;
        }

        let apptargz;

        try {
          apptargz = fs.readFileSync("repo.tar.gz");
        } catch (err) {
          resolve({ error: "could not open repo.tar.gz" });

          return;
        }

        const appName = argv.appName || "vuetsexpress";

        acc
          .upsertGitContent("blobs", `apptargz/${appName}.tar.gz`, apptargz)
          .then((result) => {
            resolve(result);
          });

        return;
      }

      if (command === "commits") {
        const acc = gitMan.getAccountByGitUserName(argv.user);

        if (!acc) {
          resolve({ error: "commits account not available" });
          return;
        }

        let page = parseInt(argv.page);
        if (isNaN(page)) page = 1;
        let perPage = parseInt(argv.perpage);
        if (isNaN(perPage)) perPage = 5;

        acc.getCommits(argv.repo, page, perPage).then((result: any) => {
          resolve(result);
        });
      }
    }
  });
}

if (require.main === module) {
  interpreter(argv).then((result: any) => {
    if (result.stdout) {
      fs.writeFileSync("clistdout", result.stdout);
    } else {
      console.log(result);
    }
  });
}
