Sources that are intended to work in any execution context.
