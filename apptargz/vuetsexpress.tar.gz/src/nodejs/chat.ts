import { Db, Collection } from "./mongodb";
import { Router } from "./utils";
import { SseServer } from "./sse";
import _ from "lodash";
import { ChatMessage } from "../shared/models";
import { DISCARD_CHAT_MESSAGE_AFTER, CHAT_TIME_QUOTA } from "./config";
import { MINUTE, SECOND } from "../shared/time";

export type ChatSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Chat {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  messagesColl: Collection;

  debounceSendMessagesToAll = _.debounce(this.sendMessages.bind(this), 3000);

  constructor(cs: ChatSetup) {
    this.appDb = cs.appDb;
    this.api = cs.api;
    this.sseServer = cs.sseServer;
    this.messagesColl = this.appDb.collection("chat", {
      onConnect: this.messagesConnected.bind(this),
    });

    this.mount();
  }

  async messagesConnected() {
    await this.messagesColl.getAll();
  }

  getSortedMessages() {
    const messages = this.messagesColl
      .getAllLocalSync()
      .sort((a: any, b: any) => a.createdAt - b.createdAt);

    return messages;
  }

  sendMessagesEvent() {
    const messages = this.getSortedMessages();

    const ev = {
      kind: "chat",
      messages,
    };

    return ev;
  }

  sendMessages() {
    this.sseServer.sendEventToAllConsumers(this.sendMessagesEvent());
  }

  checkMessagesFunc() {
    return new Promise((resolve) => {
      const messages = this.getSortedMessages();
      if (messages.length) {
        const message = new ChatMessage(messages[0]);
        if (message.age() > DISCARD_CHAT_MESSAGE_AFTER) {
          this.messagesColl.deleteOneById(message.id).then((result: any) => {
            resolve(true);
          });
        } else {
          resolve(false);
        }
      } else {
        resolve(false);
      }
    });
  }

  async checkMessages() {
    const deleted = await this.checkMessagesFunc();

    if (deleted) {
      setTimeout(this.checkMessages.bind(this), SECOND);
    } else {
      setTimeout(this.checkMessages.bind(this), 5 * MINUTE);
    }
  }

  mount() {
    this.api.postAuth("/chat", async (req: any, res: any) => {
      const user = req.lightUser;

      const exceeded = CHAT_TIME_QUOTA.exceeded(
        this.getSortedMessages(),
        (doc) => {
          return doc.user.id === user.id;
        }
      );

      if (exceeded) {
        res.json({ error: "Chat Quota Exceeded" });

        return;
      }

      const chatMessage = new ChatMessage({
        message: req.body.message,
        user,
      });

      await this.messagesColl.setDocById(
        chatMessage.id,
        chatMessage.serialize()
      );

      this.sendMessages();
    });

    this.api.post("/getchat", (req: any, res: any) => {
      res.json(this.sendMessagesEvent());
    });

    this.api.postAdmin("/deletechat", (req: any, res: any) => {
      this.messagesColl.drop().then((result) => {
        this.sendMessages();

        res.json(result);
      });
    });

    setTimeout(this.checkMessages.bind(this), MINUTE);

    return this;
  }
}
