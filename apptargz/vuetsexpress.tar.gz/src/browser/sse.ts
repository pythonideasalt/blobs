import {
  uid,
  SSE_DEFAULT_DROP_DELAY,
  SSE_DEFAULT_TICK_DELAY,
} from "../shared/utils";

import { get } from "./api";

export type EventConsumerConfig = {
  endpoint: string;
  id: string;
  name: string;
  description: string;
  pingDelay: number;
  tickDelay: number;
};

export class EventConsumer {
  endpoint = "events";
  id = uid();
  name = "eventconsumer";
  description = "eventconsumer";
  pingDelay = SSE_DEFAULT_DROP_DELAY / 2;
  tickDelay = SSE_DEFAULT_TICK_DELAY;
  lastTick = Date.now();
  source: any;

  constructor(eccOpt?: EventConsumerConfig) {
    if (eccOpt) {
      this.endpoint = eccOpt.endpoint || this.endpoint;
      this.id = eccOpt.id || this.id;
      this.name = eccOpt.name || this.name;
      this.description = eccOpt.description || this.description;
      this.pingDelay = eccOpt.pingDelay || this.pingDelay;
    }
  }

  endPointUrl() {
    return `/api/${this.endpoint}/?id=${this.id}&name=${this.name}&description=${this.description}`;
  }

  pingUrl() {
    return `${this.endpoint}/ping/?id=${this.id}`;
  }

  ping() {
    get(this.pingUrl()).then((pingResult: any) => {
      //console.log({pingResult})
    });
  }

  checkTick() {
    if (Date.now() - this.lastTick > 2 * this.tickDelay) {
      console.error("timed out", this.id);
      this.source.close();
      this.id = uid();
      this.mount();
    }
  }

  mount() {
    this.source = new EventSource(this.endPointUrl());

    this.source.onopen = () => {
      console.log("source opened", this.id);

      this.lastTick = Date.now();
    };

    this.source.onerror = () => {
      console.error("source failed", this.id);
    };

    this.source.onmessage = (ev) => {
      const data = JSON.parse(ev.data);

      const kind = data.kind;

      if (kind === "setpingdelay") {
        this.pingDelay = data.pingDelay;

        console.log("set ping delay to", this.pingDelay, this.id);

        setInterval(this.ping.bind(this), this.pingDelay);
        setInterval(this.checkTick.bind(this), this.tickDelay);
      }

      if (kind === "tick") {
        console.log(data);

        this.lastTick = Date.now();
      }
    };

    return this;
  }
}
