import { envIntElse } from "./utils";

export const LOGIN_INTERVAL = envIntElse("LOGIN_INTERVAL", 60000);
