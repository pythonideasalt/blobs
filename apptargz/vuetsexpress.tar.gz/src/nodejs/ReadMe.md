Sources that are intended to work in Node.js execution context.
