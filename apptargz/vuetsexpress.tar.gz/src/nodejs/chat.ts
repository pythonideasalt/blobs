import { Db, Collection } from "./mongodb";
import { Router, fetchJson } from "./utils";
import { SseServer } from "./sse";
import _ from "lodash";
import { ChatMessage, User } from "../shared/models";

export type ChatSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Chat {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  messagesColl: Collection;

  debounceSendMessagesToAll = _.debounce(this.sendMessages.bind(this), 3000);

  constructor(cs: ChatSetup) {
    this.appDb = cs.appDb;
    this.api = cs.api;
    this.sseServer = cs.sseServer;
    this.messagesColl = this.appDb.collection("chat", {
      onConnect: this.messagesConnected.bind(this),
    });

    this.mount();
  }

  async messagesConnected() {
    await this.messagesColl.getAll();
  }

  sendMessagesEvent() {
    const messages = this.messagesColl
      .getAllLocalSync()
      .sort((a: any, b: any) => a.createdAt - b.createdAt);

    const ev = {
      kind: "chat",
      messages,
    };

    return ev;
  }

  sendMessages() {
    this.sseServer.sendEventToAllConsumers(this.sendMessagesEvent());
  }

  checkMessages() {}

  mount() {
    this.api.postAuth("/chat", async (req: any, res: any) => {
      const user = req.user;

      const chatMessage = new ChatMessage({
        message: req.body.message,
        user,
      });

      await this.messagesColl.setDocById(
        chatMessage.id,
        chatMessage.serialize()
      );

      this.sendMessages();
    });

    this.api.post("/getchat", (req: any, res: any) => {
      res.json(this.sendMessagesEvent());
    });

    this.checkMessages();

    return this;
  }
}
