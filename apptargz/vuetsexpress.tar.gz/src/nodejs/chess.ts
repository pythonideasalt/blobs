import { Db, Collection } from "./mongodb";
import { Router } from "./utils";
import { SseServer } from "./sse";
import _ from "lodash";
import { User } from "../shared/models";
import { Serializable, Seek } from "../shared/models";
import { MAX_SEEKS } from "./config";

export type ChessSetup = {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
};

export class Chess {
  appDb: Db;
  api: Router;
  sseServer: SseServer;
  analysisColl: Collection;
  seeksColl: Collection;

  constructor(cs: ChessSetup) {
    this.appDb = cs.appDb;
    this.api = cs.api;
    this.sseServer = cs.sseServer;
    this.analysisColl = this.appDb.collection("analysis", {});
    this.seeksColl = this.appDb.collection("seeks", {
      onConnect: () => {
        return this.seeksColl.getAll();
      },
    });

    this.mount();
  }

  sendSeeksEvent() {
    return {
      kind: "seeks",
      seeks: this.seeksColl.getAllLocalSync(),
    };
  }

  async createSeek(res: any, seek: Seek, user: User) {
    seek.user = user;
    //console.log("create seek", seek.serialize())
    const existingSeek = this.seeksColl.getDocByIdLocalSync(seek.id);
    if (existingSeek) {
      if (existingSeek.user.userId === seek.user.userId) {
        const delResult = await this.seeksColl.deleteOneById(seek.id);
        res.json({ deleted: true, seekId: seek.id, delResult });
        this.sseServer.sendEventToAllConsumers(this.sendSeeksEvent());
      } else {
        res.json({ error: "Accepting a seek is not yet implemented." });
      }
    } else {
      const countOwn = this.seeksColl
        .getAllLocalSync()
        .filter((doc) => doc.user.userId === user.userId).length;
      if (countOwn >= MAX_SEEKS) {
        res.json({ error: `You can create at most ${MAX_SEEKS} seek(s).` });
        return;
      }
      await this.seeksColl.setDocById(seek.id, seek.serialize());
      this.sseServer.sendEventToAllConsumers(this.sendSeeksEvent());
      res.json({ ok: true });
    }
  }

  mount() {
    this.api.postAuth("/msg", (req: any, res: any) => {
      const user = req.user.cloneLight();

      const msgObject = Serializable.fromBlob(req.body);

      if (msgObject === undefined) {
        res.json({ error: "unknown message" });
      } else {
        if (msgObject instanceof Seek) {
          this.createSeek(res, msgObject, user);
        }
      }
    });

    this.api.postAuth("/storeanalysis", (req: any, res: any) => {
      const id = req.user.userId;

      this.analysisColl
        .setDocById(id, { game: req.body.game })
        .then((result) => {
          res.json(result);
        });
    });

    this.api.postAuth("/getanalysis", (req: any, res: any) => {
      const id = req.user.userId;

      this.analysisColl.getDocById(id, "lr").then((result) => {
        if (result) {
          res.json(result);
        } else {
          res.json({ game: false });
        }
      });
    });

    this.api.postAuth("/getseeks", (req: any, res: any) => {
      res.json({ seeks: this.seeksColl.getAllLocalSync() });
    });

    return this;
  }
}
