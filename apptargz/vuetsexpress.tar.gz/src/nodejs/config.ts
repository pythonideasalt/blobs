import { envIntElse, envBlobElse } from "./utils";
import { DAY, WEEK, SECOND, MINUTE, HOUR, TimeQuota } from "../shared/time";

export const PORT = envIntElse("PORT", 8080);
export const APP_NAME = process.env.APP_NAME || "vuetsexpress";
export const APP_DISPOSITION = process.env.APP_DISPOSITION || "prod";
export const IS_DEV = APP_DISPOSITION === "dev";
export const IS_PROD = !IS_DEV;

export const MIGRATE_INTERVAL_MINUTE = envIntElse("MIGRATE_INTERVAL", 240);

export const LOGIN_INTERVAL = envIntElse("LOGIN_INTERVAL", 60000);
export const CHECK_LICHESS_PROFILE_AFTER = DAY;
export const DISCARD_CHAT_MESSAGE_AFTER = WEEK;
export const MAX_SEEKS = 3;

export const CHAT_TIME_QUOTA = new TimeQuota().fromBlob(
  envBlobElse("CHAT_TIME_QUOTA", {
    name: "Chat",
    items: [
      { dur: 5 * SECOND, freq: 1 },
      { dur: 1 * MINUTE, freq: 5 },
      { dur: 1 * HOUR, freq: 100 },
      { dur: 1 * DAY, freq: 500 },
    ],
  })
);
